// packages/components/tree/tree.tsx
import { createVNode as _createVNode12, isVNode as _isVNode2 } from "vue";
import { isFunction as isFunction9, upperFirst } from "lodash-es";

// packages/components/tree/utils/adapt.ts
import * as Vue from "vue";

// packages/shared/hooks/icon/index.tsx
import { createVNode as _createVNode } from "vue";
import { isFunction } from "lodash-es";
import { getCurrentInstance, h } from "vue";

// packages/shared/hooks/slot/index.ts
import {
  getCurrentInstance as getCurrentInstance3,
  Fragment as Fragment2,
  Comment as Comment2,
  isVNode as isVNode3,
  Teleport
} from "vue";
import { isArray as isArray3 } from "lodash-es";

// packages/shared/utils/dom.ts
import { isVNode, Comment } from "vue";
import raf from "raf";
import { isArray, isString, isFunction as isFunction2 } from "lodash-es";
var isServer = typeof window === "undefined";
var trim = (str) => (str || "").replace(/^[\s\uFEFF]+|[\s\uFEFF]+$/g, "");
var on = (() => {
  if (!isServer && document.addEventListener) {
    return (element, event, handler, options) => {
      if (element && event && handler) {
        element.addEventListener(event, handler, options);
      }
    };
  }
  return (element, event, handler) => {
    if (element && event && handler) {
      element.attachEvent(`on${event}`, handler);
    }
  };
})();
var off = (() => {
  if (!isServer && document.removeEventListener) {
    return (element, event, handler, options) => {
      if (element && event) {
        element.removeEventListener(event, handler, options);
      }
    };
  }
  return (element, event, handler) => {
    if (element && event) {
      element.detachEvent(`on${event}`, handler);
    }
  };
})();
function hasClass(el, cls) {
  if (!el || !cls) return false;
  if (cls.indexOf(" ") !== -1) throw new Error("className should not contain space.");
  if (el.classList) {
    return el.classList.contains(cls);
  }
  return ` ${el.className} `.indexOf(` ${cls} `) > -1;
}
function addClass(el, cls) {
  if (!el) return;
  let curClass = el.className;
  const classes = (cls || "").split(" ");
  for (let i = 0, j = classes.length; i < j; i++) {
    const clsName = classes[i];
    if (!clsName) continue;
    if (el.classList) {
      el.classList.add(clsName);
    } else if (!hasClass(el, clsName)) {
      curClass += ` ${clsName}`;
    }
  }
  if (!el.classList) {
    el.className = curClass;
  }
}
function removeClass(el, cls) {
  if (!el || !cls) return;
  const classes = cls.split(" ");
  let curClass = ` ${el.className} `;
  for (let i = 0, j = classes.length; i < j; i++) {
    const clsName = classes[i];
    if (!clsName) continue;
    if (el.classList) {
      el.classList.remove(clsName);
    } else if (hasClass(el, clsName)) {
      curClass = curClass.replace(` ${clsName} `, " ");
    }
  }
  if (!el.classList) {
    el.className = trim(curClass);
  }
}
var getAttach = (node, triggerNode) => {
  const attachNode = isFunction2(node) ? node(triggerNode) : node;
  if (!attachNode) {
    return document.body;
  }
  if (isString(attachNode)) {
    return document.querySelector(attachNode);
  }
  if (attachNode instanceof HTMLElement) {
    return attachNode;
  }
  return document.body;
};
var isCommentVNode = (node) => {
  return isVNode(node) && node.type === Comment;
};

// packages/shared/utils/withInstall.ts
function withInstall(comp, alias, directive) {
  const componentPlugin = comp;
  componentPlugin.install = (app, name) => {
    app.component(alias || name || componentPlugin.name, comp);
    directive && app.directive(directive.name, directive.comp);
  };
  return componentPlugin;
}

// packages/shared/utils/render-tnode.ts
import { isVNode as isVNode2, Fragment, getCurrentInstance as getCurrentInstance2 } from "vue";
import { isArray as isArray2, isString as isString2, isObject } from "lodash-es";
function getDefaultNode(options) {
  let defaultNode;
  if (isObject(options) && "defaultNode" in options) {
    defaultNode = options.defaultNode;
  } else if (isVNode2(options) || isString2(options)) {
    defaultNode = options;
  }
  return defaultNode;
}
function getChildren(content) {
  const childList = [];
  const innerGetChildren = (content2) => {
    if (!isArray2(content2)) return;
    content2.forEach((item) => {
      if (item.children && isArray2(item.children)) {
        if (item.type !== Fragment) return;
        innerGetChildren(item.children);
      } else {
        childList.push(item);
      }
    });
    return childList;
  };
  return innerGetChildren(content);
}
function getParams(options) {
  return isObject(options) && "params" in options ? options.params : {};
}
function getSlotFirst(options) {
  return isObject(options) && "slotFirst" in options ? options.slotFirst : false;
}

// packages/shared/hooks/slot/index.ts
function useChildComponentSlots() {
  const instance = getCurrentInstance3();
  return (childComponentName, slots) => {
    if (!slots) {
      slots = instance.slots;
    }
    const content = slots?.default?.() || [];
    return getChildren(content).filter(
      (item) => item.type.name?.endsWith(childComponentName)
    );
  };
}

// packages/shared/hooks/tnode/index.ts
import { h as h2, getCurrentInstance as getCurrentInstance4 } from "vue";
import { camelCase, kebabCase, isFunction as isFunction4, isString as isString3, isObject as isObject3 } from "lodash-es";

// packages/common/js/utils/general.ts
import { isFunction as isFunction3, isObject as isObject2 } from "lodash-es";
var { hasOwnProperty } = Object.prototype;
var hasOwn = (val, key) => hasOwnProperty.call(val, key);
var getPropertyValFromObj = (val, key) => hasOwn(val, key) ? val[key] : void 0;

// packages/shared/hooks/tnode/index.ts
function handleSlots(instance, name, params) {
  let node = instance.slots[camelCase(name)]?.(params);
  if (node && node.filter((t2) => !isCommentVNode(t2)).length) return node;
  node = instance.slots[kebabCase(name)]?.(params);
  if (node && node.filter((t2) => !isCommentVNode(t2)).length) return node;
  return null;
}
function isEmptyNode(node) {
  if ([void 0, null, ""].includes(node)) return true;
  const innerNodes = node instanceof Array ? node : [node];
  const r = innerNodes.filter((node2) => node2?.type?.toString() !== "Symbol(Comment)");
  return !r.length;
}
function isPropExplicitlySet(instance, propName) {
  const vProps = instance?.vnode.props || {};
  return hasOwn(vProps, camelCase(propName)) || hasOwn(vProps, kebabCase(propName));
}
var useTNodeJSX = () => {
  const instance = getCurrentInstance4();
  return function(name, options) {
    const renderParams = getParams(options);
    const defaultNode = getDefaultNode(options);
    const isSlotFirst = getSlotFirst(options);
    const renderSlot = instance.slots[camelCase(name)] || instance.slots[kebabCase(name)];
    if (isSlotFirst && renderSlot) {
      return handleSlots(instance, name, renderParams);
    } else {
      if (isPropExplicitlySet(instance, name)) {
        const propsNode2 = instance.props[camelCase(name)] || instance.props[kebabCase(name)];
        const types = instance.type.props[name]?.type;
        if (types?.length > 1) {
          if (types.includes(Boolean) && types.includes(Function)) {
            if (propsNode2 === "" && !renderSlot) return defaultNode;
          }
        }
        if (propsNode2 === false || propsNode2 === null) return;
        if (propsNode2 === true) {
          return handleSlots(instance, name, renderParams) || defaultNode;
        }
        if (isFunction4(propsNode2)) return propsNode2(h2, renderParams);
        const isPropsEmpty = [void 0, ""].includes(propsNode2);
        if (isPropsEmpty && renderSlot) {
          return handleSlots(instance, name, renderParams);
        }
        return propsNode2;
      }
      if (renderSlot) {
        return handleSlots(instance, name, renderParams);
      }
      const propsNode = instance.props[camelCase(name)] || instance.props[kebabCase(name)];
      if (propsNode === false || propsNode === null) return;
      if (propsNode === true) {
        return defaultNode;
      }
      if (isFunction4(propsNode)) return propsNode(h2, renderParams);
      return propsNode;
    }
  };
};
var useContent = () => {
  const renderTNodeJSX = useTNodeJSX();
  return function(name1, name2, options) {
    const params = getParams(options);
    const defaultNode = getDefaultNode(options);
    const toParams = params ? { params } : void 0;
    const node1 = renderTNodeJSX(name1, toParams);
    const node2 = renderTNodeJSX(name2, toParams);
    const res = isEmptyNode(node1) ? node2 : node1;
    return isEmptyNode(res) ? defaultNode : res;
  };
};

// packages/shared/hooks/useCommonClassName/index.ts
import { computed as computed3 } from "vue";

// packages/shared/hooks/useConfig/index.ts
import { computed as computed2 } from "vue";

// packages/components/config-provider/hooks/useConfig.ts
import { computed, h as h3, inject, getCurrentInstance as getCurrentInstance5, ref, provide } from "vue";
import { cloneDeep, isFunction as isFunction5 } from "lodash-es";

// packages/components/config-provider/utils/context.ts
import { mergeWith as _mergeWith, merge, isArray as isArray4 } from "lodash-es";

// packages/common/js/global-config/default-config.ts
var default_config_default = {
  classPrefix: "t",
  animation: {
    include: ["ripple", "expand", "fade"],
    exclude: []
  },
  attach: null,
  calendar: {
    firstDayOfWeek: 1,
    fillWithZero: true,
    controllerConfig: void 0
  },
  icon: {},
  input: {
    autocomplete: ""
  },
  dialog: {
    closeOnEscKeydown: true,
    closeOnOverlayClick: true,
    placement: "top",
    confirmBtnTheme: {
      default: "primary",
      info: "primary",
      warning: "primary",
      danger: "primary",
      success: "primary"
    }
  },
  loading: {
    size: "medium",
    delay: 0,
    showOverlay: true,
    inheritColor: false,
    preventScrollThrough: true
  },
  message: {},
  popconfirm: {
    confirmBtnTheme: {
      default: "primary",
      warning: "primary",
      danger: "primary"
    }
  },
  table: {
    // 展开和收起图标（使用收起图标）
    expandIcon: void 0,
    // 排序图标（使用降序图标）
    sortIcon: void 0,
    // 过滤图标
    filterIcon: void 0,
    // 树形结构展开图标
    treeExpandAndFoldIcon: void 0,
    // 是否隐藏排序图标的文本提示
    hideSortTips: false,
    // 全局表格尺寸配置
    size: "medium"
  },
  select: {
    // 清除按钮
    clearIcon: void 0,
    filterable: false
  },
  drawer: {
    closeOnEscKeydown: true,
    closeOnOverlayClick: true,
    size: "small"
  },
  tree: {
    // 目录层级图标
    folderIcon: void 0
  },
  datePicker: {
    firstDayOfWeek: 1
  },
  steps: {
    checkIcon: void 0,
    errorIcon: void 0
  },
  tag: {
    closeIcon: void 0
  },
  form: {
    requiredMark: void 0
  },
  empty: {
    titleText: {
      maintenance: void 0,
      success: void 0,
      fail: void 0,
      empty: void 0,
      networkError: void 0
    },
    image: {
      maintenance: void 0,
      success: void 0,
      fail: void 0,
      empty: void 0,
      networkError: void 0
    }
  }
};

// packages/common/js/global-config/locale/zh_CN.ts
import "dayjs/locale/zh-cn";
var zh_CN_default = {
  autoComplete: {
    empty: "\u6682\u65E0\u6570\u636E"
  },
  pagination: {
    itemsPerPage: "{size} \u6761/\u9875",
    jumpTo: "\u8DF3\u81F3",
    page: "\u9875",
    total: "\u5171 {count} \u6761\u6570\u636E"
  },
  cascader: {
    empty: "\u6682\u65E0\u6570\u636E",
    loadingText: "\u52A0\u8F7D\u4E2D",
    placeholder: "\u8BF7\u9009\u62E9"
  },
  calendar: {
    yearSelection: "{year} \u5E74",
    monthSelection: "{month} \u6708",
    yearRadio: "\u5E74",
    monthRadio: "\u6708",
    hideWeekend: "\u9690\u85CF\u5468\u672B",
    showWeekend: "\u663E\u793A\u5468\u672B",
    today: "\u4ECA\u5929",
    thisMonth: "\u672C\u6708",
    week: "\u4E00,\u4E8C,\u4E09,\u56DB,\u4E94,\u516D,\u65E5",
    cellMonth: "1 \u6708,2 \u6708,3 \u6708,4 \u6708,5 \u6708,6 \u6708,7 \u6708,8 \u6708,9 \u6708,10 \u6708,11 \u6708,12 \u6708"
  },
  transfer: {
    title: "{checked} / {total} \u9879",
    empty: "\u6682\u65E0\u6570\u636E",
    placeholder: "\u8BF7\u8F93\u5165\u5173\u952E\u8BCD\u641C\u7D22"
  },
  timePicker: {
    dayjsLocale: "zh-cn",
    now: "\u6B64\u523B",
    confirm: "\u786E\u5B9A",
    anteMeridiem: "\u4E0A\u5348",
    postMeridiem: "\u4E0B\u5348",
    placeholder: "\u9009\u62E9\u65F6\u95F4"
  },
  dialog: {
    confirm: "\u786E\u8BA4",
    cancel: "\u53D6\u6D88"
  },
  drawer: {
    confirm: "\u786E\u8BA4",
    cancel: "\u53D6\u6D88"
  },
  popconfirm: {
    confirm: {
      content: "\u786E\u5B9A"
    },
    cancel: {
      content: "\u53D6\u6D88"
    }
  },
  table: {
    empty: "\u6682\u65E0\u6570\u636E",
    loadingText: "\u6B63\u5728\u52A0\u8F7D\u4E2D\uFF0C\u8BF7\u7A0D\u540E",
    loadingMoreText: "\u70B9\u51FB\u52A0\u8F7D\u66F4\u591A",
    filterInputPlaceholder: "\u8BF7\u8F93\u5165\u5185\u5BB9\uFF08\u65E0\u9ED8\u8BA4\u503C\uFF09",
    sortAscendingOperationText: "\u70B9\u51FB\u5347\u5E8F",
    sortCancelOperationText: "\u70B9\u51FB\u53D6\u6D88\u6392\u5E8F",
    sortDescendingOperationText: "\u70B9\u51FB\u964D\u5E8F",
    clearFilterResultButtonText: "\u6E05\u7A7A\u7B5B\u9009",
    columnConfigButtonText: "\u5217\u914D\u7F6E",
    columnConfigTitleText: "\u8868\u683C\u5217\u914D\u7F6E",
    columnConfigDescriptionText: "\u8BF7\u9009\u62E9\u9700\u8981\u5728\u8868\u683C\u4E2D\u663E\u793A\u7684\u6570\u636E\u5217",
    confirmText: "\u786E\u8BA4",
    cancelText: "\u53D6\u6D88",
    resetText: "\u91CD\u7F6E",
    selectAllText: "\u5168\u9009",
    searchResultText: "\u641C\u7D22\u201C{result}\u201D\uFF0C\u627E\u5230 {count} \u6761\u7ED3\u679C"
  },
  select: {
    empty: "\u6682\u65E0\u6570\u636E",
    loadingText: "\u52A0\u8F7D\u4E2D",
    placeholder: "\u8BF7\u9009\u62E9"
  },
  tree: {
    empty: "\u6682\u65E0\u6570\u636E"
  },
  treeSelect: {
    empty: "\u6682\u65E0\u6570\u636E",
    loadingText: "\u52A0\u8F7D\u4E2D",
    placeholder: "\u8BF7\u9009\u62E9"
  },
  datePicker: {
    dayjsLocale: "zh-cn",
    placeholder: {
      date: "\u8BF7\u9009\u62E9\u65E5\u671F",
      month: "\u8BF7\u9009\u62E9\u6708\u4EFD",
      year: "\u8BF7\u9009\u62E9\u5E74\u4EFD",
      quarter: "\u8BF7\u9009\u62E9\u5B63\u5EA6",
      week: "\u8BF7\u9009\u62E9\u5468"
    },
    weekdays: ["\u4E00", "\u4E8C", "\u4E09", "\u56DB", "\u4E94", "\u516D", "\u65E5"],
    months: ["1 \u6708", "2 \u6708", "3 \u6708", "4 \u6708", "5 \u6708", "6 \u6708", "7 \u6708", "8 \u6708", "9 \u6708", "10 \u6708", "11 \u6708", "12 \u6708"],
    quarters: ["\u4E00\u5B63\u5EA6", "\u4E8C\u5B63\u5EA6", "\u4E09\u5B63\u5EA6", "\u56DB\u5B63\u5EA6"],
    rangeSeparator: " - ",
    direction: "ltr",
    format: "YYYY-MM-DD",
    dayAriaLabel: "\u65E5",
    weekAbbreviation: "\u5468",
    yearAriaLabel: "\u5E74",
    monthAriaLabel: "\u6708",
    confirm: "\u786E\u5B9A",
    selectTime: "\u9009\u62E9\u65F6\u95F4",
    selectDate: "\u9009\u62E9\u65E5\u671F",
    nextYear: "\u4E0B\u4E00\u5E74",
    preYear: "\u4E0A\u4E00\u5E74",
    nextMonth: "\u4E0B\u4E2A\u6708",
    preMonth: "\u4E0A\u4E2A\u6708",
    preDecade: "\u4E0A\u4E2A\u5341\u5E74",
    nextDecade: "\u4E0B\u4E2A\u5341\u5E74",
    now: "\u5F53\u524D"
  },
  upload: {
    sizeLimitMessage: "\u6587\u4EF6\u5927\u5C0F\u4E0D\u80FD\u8D85\u8FC7 {sizeLimit}",
    cancelUploadText: "\u53D6\u6D88\u4E0A\u4F20",
    triggerUploadText: {
      fileInput: "\u9009\u62E9\u6587\u4EF6",
      image: "\u70B9\u51FB\u4E0A\u4F20\u56FE\u7247",
      normal: "\u70B9\u51FB\u4E0A\u4F20",
      // 选择文件和上传文件是 2 个步骤，文本需明确步骤
      reupload: "\u91CD\u65B0\u9009\u62E9",
      continueUpload: "\u7EE7\u7EED\u9009\u62E9",
      delete: "\u5220\u9664",
      uploading: "\u4E0A\u4F20\u4E2D"
    },
    dragger: {
      dragDropText: "\u91CA\u653E\u9F20\u6807",
      draggingText: "\u62D6\u62FD\u5230\u6B64\u533A\u57DF",
      clickAndDragText: "\u70B9\u51FB\u4E0A\u65B9\u201C\u9009\u62E9\u6587\u4EF6\u201D\u6216\u5C06\u6587\u4EF6\u62D6\u62FD\u5230\u6B64\u533A\u57DF"
    },
    file: {
      fileNameText: "\u6587\u4EF6\u540D",
      fileSizeText: "\u6587\u4EF6\u5927\u5C0F",
      fileStatusText: "\u72B6\u6001",
      fileOperationText: "\u64CD\u4F5C",
      fileOperationDateText: "\u4E0A\u4F20\u65E5\u671F"
    },
    progress: {
      uploadingText: "\u4E0A\u4F20\u4E2D",
      waitingText: "\u5F85\u4E0A\u4F20",
      failText: "\u4E0A\u4F20\u5931\u8D25",
      successText: "\u4E0A\u4F20\u6210\u529F"
    }
  },
  form: {
    errorMessage: {
      date: "\u8BF7\u8F93\u5165\u6B63\u786E\u7684${name}",
      url: "\u8BF7\u8F93\u5165\u6B63\u786E\u7684${name}",
      required: "${name}\u5FC5\u586B",
      whitespace: "${name}\u4E0D\u80FD\u4E3A\u7A7A",
      max: "${name}\u5B57\u7B26\u957F\u5EA6\u4E0D\u80FD\u8D85\u8FC7 ${validate} \u4E2A\u5B57\u7B26\uFF0C\u4E00\u4E2A\u4E2D\u6587\u7B49\u4E8E\u4E24\u4E2A\u5B57\u7B26",
      min: "${name}\u5B57\u7B26\u957F\u5EA6\u4E0D\u80FD\u5C11\u4E8E ${validate} \u4E2A\u5B57\u7B26\uFF0C\u4E00\u4E2A\u4E2D\u6587\u7B49\u4E8E\u4E24\u4E2A\u5B57\u7B26",
      len: "${name}\u5B57\u7B26\u957F\u5EA6\u5FC5\u987B\u662F ${validate}",
      enum: "${name}\u53EA\u80FD\u662F${validate}\u7B49",
      idcard: "\u8BF7\u8F93\u5165\u6B63\u786E\u7684${name}",
      telnumber: "\u8BF7\u8F93\u5165\u6B63\u786E\u7684${name}",
      pattern: "\u8BF7\u8F93\u5165\u6B63\u786E\u7684${name}",
      validator: "${name}\u4E0D\u7B26\u5408\u8981\u6C42",
      boolean: "${name}\u6570\u636E\u7C7B\u578B\u5FC5\u987B\u662F\u5E03\u5C14\u7C7B\u578B",
      number: "${name}\u5FC5\u987B\u662F\u6570\u5B57",
      email: "\u8BF7\u8F93\u5165\u6B63\u786E\u7684${name}"
    },
    colonText: "\uFF1A"
  },
  input: {
    placeholder: "\u8BF7\u8F93\u5165"
  },
  list: {
    loadingText: "\u6B63\u5728\u52A0\u8F7D\u4E2D\uFF0C\u8BF7\u7A0D\u7B49",
    loadingMoreText: "\u70B9\u51FB\u52A0\u8F7D\u66F4\u591A"
  },
  alert: {
    expandText: "\u5C55\u5F00\u66F4\u591A",
    collapseText: "\u6536\u8D77"
  },
  anchor: {
    copySuccessText: "\u94FE\u63A5\u590D\u5236\u6210\u529F",
    copyText: "\u590D\u5236\u94FE\u63A5"
  },
  colorPicker: {
    swatchColorTitle: "\u7CFB\u7EDF\u9884\u8BBE\u989C\u8272",
    recentColorTitle: "\u6700\u8FD1\u4F7F\u7528\u989C\u8272",
    clearConfirmText: "\u786E\u5B9A\u6E05\u7A7A\u6700\u8FD1\u4F7F\u7528\u7684\u989C\u8272\u5417\uFF1F",
    singleColor: "\u5355\u8272",
    gradientColor: "\u6E10\u53D8"
  },
  guide: {
    finishButtonProps: {
      content: "\u5B8C\u6210",
      theme: "primary"
    },
    nextButtonProps: {
      content: "\u4E0B\u4E00\u6B65",
      theme: "primary"
    },
    skipButtonProps: {
      content: "\u8DF3\u8FC7",
      theme: "default"
    },
    prevButtonProps: {
      content: "\u4E0A\u4E00\u6B65",
      theme: "default"
    }
  },
  image: {
    errorText: "\u56FE\u7247\u65E0\u6CD5\u663E\u793A",
    loadingText: "\u56FE\u7247\u52A0\u8F7D\u4E2D"
  },
  imageViewer: {
    errorText: "\u56FE\u7247\u52A0\u8F7D\u5931\u8D25\uFF0C\u53EF\u5C1D\u8BD5\u91CD\u65B0\u52A0\u8F7D",
    mirrorTipText: "\u955C\u50CF",
    rotateTipText: "\u65CB\u8F6C",
    originalSizeTipText: "\u539F\u59CB\u5927\u5C0F",
    previewText: "\u9884\u89C8"
  },
  typography: {
    expandText: "\u5C55\u5F00",
    collapseText: "\u6536\u8D77",
    copiedText: "\u590D\u5236\u6210\u529F"
  },
  rate: {
    rateText: ["\u6781\u5DEE", "\u5931\u671B", "\u4E00\u822C", "\u6EE1\u610F", "\u60CA\u559C"]
  },
  empty: {
    titleText: {
      maintenance: "\u5EFA\u8BBE\u4E2D",
      success: "\u6210\u529F",
      fail: "\u5931\u8D25",
      empty: "\u6682\u65E0\u6570\u636E",
      networkError: "\u7F51\u7EDC\u9519\u8BEF"
    }
  },
  descriptions: {
    colonText: "\uFF1A"
  },
  chat: {
    placeholder: "\u8BF7\u8F93\u5165\u6D88\u606F...",
    stopBtnText: "\u4E2D\u6B62",
    refreshTipText: "\u91CD\u65B0\u751F\u6210",
    copyTipText: "\u590D\u5236",
    likeTipText: "\u70B9\u8D5E",
    dislikeTipText: "\u70B9\u8E29",
    copyCodeBtnText: "\u590D\u5236\u4EE3\u7801",
    copyCodeSuccessText: "\u5DF2\u590D\u5236",
    clearHistoryBtnText: "\u6E05\u7A7A\u5386\u53F2\u8BB0\u5F55",
    copyTextSuccess: "\u5DF2\u6210\u529F\u590D\u5236\u5230\u526A\u8D34\u677F",
    copyTextFail: "\u590D\u5236\u5230\u526A\u8D34\u677F\u5931\u8D25",
    confirmClearHistory: "\u786E\u5B9A\u8981\u6E05\u7A7A\u6240\u6709\u7684\u6D88\u606F\u5417\uFF1F",
    loadingText: "\u601D\u8003\u4E2D...",
    loadingEndText: "\u5DF2\u6DF1\u5EA6\u601D\u8003",
    uploadImageText: "\u4E0A\u4F20\u56FE\u7247",
    uploadAttachmentText: "\u4E0A\u4F20\u9644\u4EF6",
    shareTipText: "\u5206\u4EAB"
  },
  qrcode: {
    expiredText: "\u4E8C\u7EF4\u7801\u8FC7\u671F",
    refreshText: "\u70B9\u51FB\u5237\u65B0",
    scannedText: "\u5DF2\u626B\u63CF"
  }
};

// packages/components/config-provider/utils/context.ts
var EAnimationType = /* @__PURE__ */ ((EAnimationType2) => {
  EAnimationType2["ripple"] = "ripple";
  EAnimationType2["expand"] = "expand";
  EAnimationType2["fade"] = "fade";
  return EAnimationType2;
})(EAnimationType || {});
var defaultGlobalConfig = merge(default_config_default, zh_CN_default);
var configProviderInjectKey = Symbol("configProvide");

// packages/common/js/global-config/t.ts
import { isString as isString4 } from "lodash-es";
function getPluralIndex(count) {
  if (count === 0) return 0;
  if (count === 1) return 1;
  return 2;
}
function t(pattern, ...args) {
  if (isString4(pattern)) {
    let text = pattern;
    let count;
    let data = {};
    if (args.length > 0) {
      const [firstArg, secondArg] = args;
      if (typeof firstArg === "number") {
        count = firstArg;
        if (secondArg && typeof secondArg === "object") {
          data = secondArg;
        } else {
          data.count = count;
        }
      } else if (typeof firstArg === "object" && firstArg !== null) {
        data = firstArg;
      }
    }
    if (text.includes("|")) {
      const pluralParts = text.split("|").map((part) => part.trim());
      let effectiveCount;
      if (typeof count === "number") {
        effectiveCount = count;
      } else if (typeof data?.count === "number") {
        effectiveCount = data.count;
      }
      if (typeof effectiveCount === "number") {
        const pluralIndex = getPluralIndex(effectiveCount);
        if (pluralIndex < pluralParts.length) {
          text = pluralParts[pluralIndex];
        } else {
          text = pluralParts[pluralParts.length - 1];
        }
      } else {
        const [firstPart] = pluralParts;
        text = firstPart;
      }
    }
    if (data && Object.keys(data).length > 0) {
      const regular = /\{\s*([\w-]+)\s*\}/g;
      text = text.replace(regular, (match, key) => {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
          return String(data[key]);
        }
        return match;
      });
    }
    return text;
  }
  return "";
}

// packages/components/config-provider/hooks/useConfig.ts
var globalConfigCopy = ref();
function useConfig(componentName = void 0, componentLocale) {
  let injectGlobalConfig = null;
  if (getCurrentInstance5()) {
    injectGlobalConfig = inject(configProviderInjectKey, null);
    if (!injectGlobalConfig) {
      injectGlobalConfig = globalConfigCopy;
    }
  } else {
    injectGlobalConfig = globalConfigCopy;
  }
  const mergedGlobalConfig = computed(() => injectGlobalConfig?.value || defaultGlobalConfig);
  const globalConfig = computed(() => Object.assign({}, mergedGlobalConfig.value[componentName], componentLocale));
  const classPrefix = computed(() => {
    return mergedGlobalConfig.value.classPrefix;
  });
  const t2 = function(pattern, ...args) {
    if (isFunction5(pattern)) {
      if (!args.length) return pattern(h3);
      return pattern(...args);
    }
    return t(pattern, ...args);
  };
  return {
    t: t2,
    global: globalConfig,
    globalConfig,
    classPrefix
  };
}

// packages/shared/hooks/useConfig/index.ts
function usePrefixClass(componentName) {
  const { classPrefix } = useConfig("classPrefix");
  return computed2(() => {
    return componentName ? `${classPrefix.value}-${componentName}` : classPrefix.value;
  });
}

// packages/shared/hooks/useCommonClassName/index.ts
function useCommonClassName() {
  const { classPrefix } = useConfig("classPrefix");
  return {
    classPrefix,
    SIZE: computed3(() => ({
      small: `${classPrefix.value}-size-s`,
      medium: `${classPrefix.value}-size-m`,
      large: `${classPrefix.value}-size-l`,
      default: "",
      xs: `${classPrefix.value}-size-xs`,
      xl: `${classPrefix.value}-size-xl`,
      block: `${classPrefix.value}-size-full-width`
    })),
    STATUS: computed3(() => ({
      loading: `${classPrefix.value}-is-loading`,
      loadMore: `${classPrefix.value}-is-load-more`,
      disabled: `${classPrefix.value}-is-disabled`,
      focused: `${classPrefix.value}-is-focused`,
      success: `${classPrefix.value}-is-success`,
      error: `${classPrefix.value}-is-error`,
      warning: `${classPrefix.value}-is-warning`,
      selected: `${classPrefix.value}-is-selected`,
      active: `${classPrefix.value}-is-active`,
      checked: `${classPrefix.value}-is-checked`,
      current: `${classPrefix.value}-is-current`,
      hidden: `${classPrefix.value}-is-hidden`,
      visible: `${classPrefix.value}-is-visible`,
      expanded: `${classPrefix.value}-is-expanded`,
      indeterminate: `${classPrefix.value}-is-indeterminate`
    }))
  };
}

// packages/shared/hooks/useDefaultValue/index.ts
import { ref as ref2, getCurrentInstance as getCurrentInstance6, unref } from "vue";
import { kebabCase as kebabCase2 } from "lodash-es";
function useDefaultValue(value, defaultValue, onChange, propsName) {
  const { emit, vnode } = getCurrentInstance6();
  const internalValue = ref2();
  const triggerChange = (newValue, ...args) => {
    unref(onChange)?.(newValue, ...args);
  };
  const vProps = vnode.props || {};
  const isVMP = Object.prototype.hasOwnProperty.call(vProps, propsName) || Object.prototype.hasOwnProperty.call(vProps, kebabCase2(propsName));
  if (isVMP) {
    return [
      value,
      (newValue, ...args) => {
        emit(`update:${propsName}`, newValue);
        triggerChange(newValue, ...args);
      }
    ];
  }
  internalValue.value = defaultValue;
  return [
    internalValue,
    (newValue, ...args) => {
      internalValue.value = newValue;
      triggerChange(newValue, ...args);
    }
  ];
}

// packages/shared/hooks/useDestroyOnClose/index.ts
import { ref as ref3, provide as provide2, onUpdated } from "vue";

// packages/shared/hooks/useDisabled/index.ts
import { inject as inject2, computed as computed4, getCurrentInstance as getCurrentInstance7 } from "vue";
import { isArray as isArray5, isBoolean } from "lodash-es";
function useDisabled(context) {
  const currentInstance = getCurrentInstance7();
  const componentDisabled = computed4(() => currentInstance.props.disabled);
  const formDisabled = inject2("formDisabled", /* @__PURE__ */ Object.create(null));
  return computed4(() => {
    if (isArray5(componentDisabled.value) && componentDisabled.value.length === 2) return componentDisabled.value;
    if (isBoolean(context?.beforeDisabled?.value)) return context.beforeDisabled.value;
    if (isBoolean(componentDisabled.value)) return componentDisabled.value;
    if (isBoolean(context?.afterDisabled?.value)) return context.afterDisabled.value;
    if (isBoolean(formDisabled.disabled?.value)) return formDisabled.disabled.value;
    return false;
  });
}

// packages/shared/hooks/useDragSort/index.ts
import { onUnmounted } from "vue";

// packages/shared/hooks/useElementLazyRender/index.ts
import { onBeforeUnmount, onMounted, ref as ref4, watch } from "vue";

// packages/common/js/utils/observe.ts
function observe(element, root, callback, marginBottom) {
  if (typeof window === "undefined") return null;
  if (!window || !window.IntersectionObserver) {
    callback();
    return null;
  }
  let io = null;
  try {
    io = new window.IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry.isIntersecting) {
          callback();
          io.unobserve(element);
        }
      },
      {
        rootMargin: `0px 0px ${marginBottom}px 0px`,
        root
      }
    );
    io.observe(element);
  } catch (e) {
    console.error(e);
    callback();
  }
  return io;
}

// packages/shared/hooks/useGlobalIcon/index.ts
function useGlobalIcon(tdIcon) {
  const { globalConfig } = useConfig("icon");
  const resultIcon = {};
  Object.keys(tdIcon).forEach((key) => {
    resultIcon[key] = globalConfig.value?.[key] || tdIcon[key];
  });
  return resultIcon;
}

// packages/shared/hooks/useImagePreviewUrl/index.ts
import { ref as ref5, watch as watch2 } from "vue";

// packages/common/js/log/log.ts
var logSet = /* @__PURE__ */ new Set();
var log = {
  warn(componentName, message) {
    console.warn(`TDesign ${componentName} Warn: ${message}`);
  },
  warnOnce(componentName, message) {
    const msgContent = `TDesign ${componentName} Warn: ${message}`;
    if (logSet.has(msgContent)) return;
    logSet.add(msgContent);
    console.warn(msgContent);
  },
  error(componentName, message) {
    console.error(`TDesign ${componentName} Error: ${message}`);
  },
  errorOnce(componentName, message) {
    const msgContent = `TDesign ${componentName} Error: ${message}`;
    if (logSet.has(msgContent)) return;
    logSet.add(msgContent);
    console.error(msgContent);
  },
  info(componentName, message) {
    console.info(`TDesign ${componentName} Info: ${message}`);
  }
};
var log_default = log;

// packages/shared/hooks/useKeepAnimation/index.ts
var { expand, ripple, fade } = EAnimationType;
function useKeepAnimation() {
  const { globalConfig } = useConfig("animation");
  const keepAnimation = (type) => {
    const animationConfig = globalConfig.value;
    return animationConfig && !animationConfig.exclude?.includes(type) && animationConfig.include?.includes(type);
  };
  return {
    keepExpand: keepAnimation(expand),
    keepRipple: keepAnimation(ripple),
    keepFade: keepAnimation(fade)
  };
}

// packages/shared/hooks/useLazyLoad/index.ts
import { ref as ref6, onMounted as onMounted2, computed as computed5, nextTick } from "vue";
function useLazyLoad(containerRef, childRef, params) {
  const tRowHeight = computed5(() => Math.max(params.rowHeight || 48, 48));
  const isInit = ref6(false);
  const hasLazyLoadHolder = computed5(() => params?.type === "lazy" && !isInit.value);
  const requestAnimationFrame = !isServer && window.requestAnimationFrame || ((cb) => setTimeout(cb, 16.6));
  const init = () => {
    if (!isInit.value) {
      requestAnimationFrame(() => {
        isInit.value = true;
      });
    }
  };
  onMounted2(() => {
    if (params?.type !== "lazy") return;
    nextTick(() => {
      const bufferSize = Math.max(10, params.bufferSize || 10);
      const height = tRowHeight.value * bufferSize;
      observe(childRef.value, containerRef.value, init, height);
    });
  });
  return {
    hasLazyLoadHolder,
    tRowHeight
  };
}

// packages/shared/hooks/useListener/index.ts
import { onBeforeUnmount as onBeforeUnmount2, onMounted as onMounted3 } from "vue";

// packages/shared/hooks/usePopupManager/index.ts
import { onMounted as onMounted4, onBeforeUnmount as onBeforeUnmount3, readonly, ref as ref7, watch as watch3 } from "vue";
var popupStackType = ["dialog", "drawer"];
var POPUP_BASE_Z_INDEX = 1e3;
var MESSAGE_BASE_Z_INDEX = 5e3;
var Z_INDEX_STEP = 1;
var PopupManager = class {
  popupStack = {
    popup: /* @__PURE__ */ new Set(),
    dialog: /* @__PURE__ */ new Set(),
    message: /* @__PURE__ */ new Set(),
    drawer: /* @__PURE__ */ new Set()
  };
  zIndexStack = [];
  getNextZIndex = (type) => {
    const current = type === "message" ? Array.from(this.popupStack.message).pop() || MESSAGE_BASE_Z_INDEX : Array.from(this.popupStack.popup).pop() || POPUP_BASE_Z_INDEX;
    return current + Z_INDEX_STEP;
  };
  add = (type) => {
    const zIndex = this.getNextZIndex(type);
    this.popupStack[type].add(zIndex);
    if (popupStackType.includes(type)) {
      this.popupStack.popup.add(zIndex);
    }
    this.zIndexStack.push(zIndex);
    return zIndex;
  };
  delete = (zIndex, type) => {
    this.popupStack[type].delete(zIndex);
    if (popupStackType.includes(type)) {
      this.popupStack.popup.delete(zIndex);
    }
    const index = this.zIndexStack.indexOf(zIndex);
    if (index !== -1) {
      this.zIndexStack.splice(index, 1);
    }
  };
  // 最顶层的交互式弹窗（指Dialog和Drawer）
  isTopInteractivePopup = (popupType, zIndex) => {
    if (popupStackType.includes(popupType)) {
      const lastZIndex = this.zIndexStack[this.zIndexStack.length - 1];
      return zIndex === lastZIndex;
    }
    if (this.popupStack[popupType]?.size > 1) {
      return zIndex === Array.from(this.popupStack[popupType]).pop();
    }
    return true;
  };
  getLastZIndex = () => {
    return this.zIndexStack[this.zIndexStack.length - 1];
  };
};
var popupManager = new PopupManager();

// packages/shared/hooks/useReadonly/index.ts
import { inject as inject3, computed as computed6, getCurrentInstance as getCurrentInstance8 } from "vue";
import { isBoolean as isBoolean2 } from "lodash-es";
function useReadonly(context) {
  const currentInstance = getCurrentInstance8();
  const componentReadonly = computed6(() => currentInstance.props.readonly);
  const formReadonly = inject3("formReadonly", /* @__PURE__ */ Object.create(null));
  return computed6(() => {
    if (isBoolean2(context?.beforeReadonly?.value)) return context.beforeReadonly.value;
    if (isBoolean2(componentReadonly?.value)) return componentReadonly.value;
    if (isBoolean2(context?.afterReadonly?.value)) return context.afterReadonly.value;
    if (isBoolean2(formReadonly.readonly?.value)) return formReadonly.readonly.value;
    return false;
  });
}

// packages/shared/hooks/useResizeObserver/index.ts
import { watch as watch4, onBeforeUnmount as onBeforeUnmount4 } from "vue";
function useResizeObserver(container, callback) {
  if (typeof window === "undefined") return;
  const isSupport = window && window.ResizeObserver;
  if (!isSupport) return;
  let containerObserver = null;
  const cleanupObserver = () => {
    if (!containerObserver || !container.value) return;
    containerObserver.unobserve(container.value);
    containerObserver.disconnect();
    containerObserver = null;
  };
  const addObserver = (el) => {
    containerObserver = new ResizeObserver(callback);
    containerObserver.observe(el);
  };
  container && watch4(
    container,
    (el) => {
      cleanupObserver();
      el && addObserver(el);
    },
    { immediate: true, flush: "post" }
  );
  onBeforeUnmount4(() => {
    cleanupObserver();
  });
}

// packages/shared/hooks/useRipple/index.ts
import { ref as ref8, onMounted as onMounted5, onUnmounted as onUnmounted2 } from "vue";

// packages/common/js/utils/setStyle.ts
function setStyle(el, styles) {
  if (!el) return;
  const keys = Object.keys(styles);
  keys.forEach((key) => {
    el.style[key] = styles[key];
  });
}
var setStyle_default = setStyle;

// packages/shared/hooks/useRipple/index.ts
var period = 200;
var rippleExtraWidth = 20;
var rippleSkew = "skewX(-8deg)";
var elementTransitionPeriod = 200;
var noneRippleBg = "rgba(0, 0, 0, 0)";
var defaultRippleColor = "rgba(0, 0, 0, 0.35)";
var getRippleColor = (el, fixedRippleColor) => {
  if (fixedRippleColor) {
    return fixedRippleColor;
  }
  if (el?.dataset?.ripple) {
    const rippleColor = el.dataset.ripple;
    return rippleColor;
  }
  if (el instanceof Element) {
    const cssVariable = getComputedStyle(el).getPropertyValue("--ripple-color");
    if (cssVariable) {
      return cssVariable;
    }
  }
  return defaultRippleColor;
};
function useRipple(el, fixedRippleColor) {
  const rippleContainer = ref8(null);
  const classPrefix = usePrefixClass();
  const { keepRipple } = useKeepAnimation();
  const handleAddRipple = (e) => {
    const dom = el.value;
    if (!dom || !(dom instanceof Element)) return;
    const rippleColor = getRippleColor(dom, fixedRippleColor?.value);
    if (e.button !== 0 || !el || !keepRipple) return;
    if (dom.classList.contains(`${classPrefix.value}-is-active`) || dom.classList.contains(`${classPrefix.value}-is-disabled`) || dom.classList.contains(`${classPrefix.value}-is-checked`) || dom.classList.contains(`${classPrefix.value}-is-loading`))
      return;
    if (!(dom instanceof Element)) return;
    const elStyle = getComputedStyle(dom);
    const elBorder = parseInt(elStyle.borderWidth, 10);
    const border = elBorder > 0 ? elBorder : 0;
    if (rippleContainer.value.parentNode === null) {
      setStyle_default(rippleContainer.value, {
        position: "absolute",
        left: `${0 - border}px`,
        top: `${0 - border}px`,
        // 使用百分比尺寸，避免点击后元素尺寸（如 loading 状态新增 icon）发生变化时，
        // 容器无法跟随元素撑开，导致右侧露出元素自身的过渡背景从而出现"左右割裂"
        width: `calc(100% + ${border * 2}px)`,
        height: `calc(100% + ${border * 2}px)`,
        borderRadius: elStyle.borderRadius,
        pointerEvents: "none",
        overflow: "hidden"
      });
      dom.appendChild(rippleContainer.value);
    }
    const ripple2 = document.createElement("div");
    setStyle_default(ripple2, {
      marginTop: "0",
      marginLeft: "0",
      right: "100%",
      // 使用百分比尺寸与位移，让 ripple 在 loading icon 插入导致按钮变宽时仍覆盖完整按钮
      width: `calc(100% + ${rippleExtraWidth}px)`,
      height: "100%",
      transition: `transform ${period}ms cubic-bezier(.38, 0, .24, 1), background ${period * 2}ms linear`,
      transform: rippleSkew,
      pointerEvents: "none",
      position: "absolute",
      zIndex: 0,
      backgroundColor: rippleColor,
      opacity: "0.9"
    });
    const elMap = /* @__PURE__ */ new WeakMap();
    for (let n = dom.children.length, i = 0; i < n; ++i) {
      const child = dom.children[i];
      if (child.style.zIndex === "" && child !== rippleContainer.value) {
        child.style.zIndex = "1";
        elMap.set(child, true);
      }
    }
    let initPosition = dom.style.position;
    if (!initPosition && dom instanceof Element) {
      initPosition = getComputedStyle(dom).position;
    }
    if (initPosition === "" || initPosition === "static") {
      dom.style.position = "relative";
    }
    rippleContainer.value.insertBefore(ripple2, rippleContainer.value.firstChild);
    setTimeout(() => {
      ripple2.style.transform = `translateX(calc(100% - ${rippleExtraWidth}px)) ${rippleSkew}`;
    }, 0);
    let cleared = false;
    let classChangeObserver = null;
    const handleClearRipple = () => {
      if (cleared) return;
      cleared = true;
      ripple2.style.backgroundColor = noneRippleBg;
      if (classChangeObserver) {
        classChangeObserver.disconnect();
        classChangeObserver = null;
      }
      if (el.value) {
        el.value.removeEventListener("pointerup", handleClearRipple, false);
        el.value.removeEventListener("pointerleave", handleClearRipple, false);
      }
      setTimeout(() => {
        ripple2.remove();
        if (rippleContainer.value.children.length === 0) rippleContainer.value.remove();
      }, period * 2 + 100);
    };
    if (typeof MutationObserver !== "undefined") {
      classChangeObserver = new MutationObserver(() => {
        if (!dom || !(dom instanceof Element)) return;
        const cls = dom.classList;
        if (cls.contains(`${classPrefix.value}-is-loading`) || cls.contains(`${classPrefix.value}-is-disabled`) || cls.contains(`${classPrefix.value}-is-active`) || cls.contains(`${classPrefix.value}-is-checked`)) {
          ripple2.style.transition = `transform ${period}ms cubic-bezier(.38, 0, .24, 1), background ${elementTransitionPeriod}ms linear`;
          handleClearRipple();
        }
      });
      classChangeObserver.observe(dom, { attributes: true, attributeFilter: ["class"] });
    }
    el.value.addEventListener("pointerup", handleClearRipple, false);
    el.value.addEventListener("pointerleave", handleClearRipple, false);
  };
  onMounted5(() => {
    const dom = el?.value;
    if (!dom) return;
    rippleContainer.value = document.createElement("div");
    dom.addEventListener("pointerdown", handleAddRipple, false);
  });
  onUnmounted2(() => {
    el?.value?.removeEventListener("pointerdown", handleAddRipple, false);
  });
}

// packages/shared/hooks/useTeleport/index.ts
import { computed as computed7, onMounted as onMounted6, ref as ref9, watch as watch5 } from "vue";
import { isFunction as isFunction6 } from "lodash-es";
function useTeleport(attach, triggerNode) {
  const to = isFunction6(attach) ? computed7(attach) : ref9(attach);
  const innerTriggerNode = isFunction6(triggerNode) ? computed7(triggerNode) : ref9(triggerNode);
  const element = ref9();
  const getElement = () => {
    element.value = getAttach(to.value, innerTriggerNode.value);
  };
  onMounted6(() => getElement());
  watch5([to, innerTriggerNode], () => getElement());
  return element;
}

// packages/shared/hooks/useVModel/index.ts
import { ref as ref10, getCurrentInstance as getCurrentInstance9, unref as unref2 } from "vue";
import { kebabCase as kebabCase3 } from "lodash-es";
function useVModel(value, modelValue, defaultValue, onChange, propName = "value") {
  const { emit, vnode } = getCurrentInstance9();
  const internalValue = ref10();
  const triggerChange = (newValue, ...args) => {
    unref2(onChange)?.(newValue, ...args);
  };
  const vProps = vnode.props || {};
  const isVM = Object.prototype.hasOwnProperty.call(vProps, "modelValue") || Object.prototype.hasOwnProperty.call(vProps, "model-value");
  const isVMP = Object.prototype.hasOwnProperty.call(vProps, propName) || Object.prototype.hasOwnProperty.call(vProps, kebabCase3(propName));
  if (isVM) {
    return [
      modelValue,
      (newValue, ...args) => {
        emit("update:modelValue", newValue);
        triggerChange(newValue, ...args);
      }
    ];
  }
  if (isVMP) {
    return [
      value,
      (newValue, ...args) => {
        emit(`update:${propName}`, newValue);
        triggerChange(newValue, ...args);
      }
    ];
  }
  internalValue.value = defaultValue;
  return [
    internalValue,
    (newValue, ...args) => {
      internalValue.value = newValue;
      triggerChange(newValue, ...args);
    }
  ];
}

// packages/shared/hooks/useVirtualScroll/index.ts
import { ref as ref11, toRefs, reactive, onMounted as onMounted7, computed as computed8, watch as watch6, nextTick as nextTick2 } from "vue";

// packages/shared/hooks/useVirtualScrollNew/index.ts
import { ref as ref12, computed as computed9, watch as watch7 } from "vue";
import { max, min, sum, throttle } from "lodash-es";
function useVirtualScrollNew(container, params) {
  const visibleData = ref12([]);
  const translateY = ref12((params.value.data?.length || 0) * (params.value.scroll?.rowHeight || 50));
  const scrollHeight = ref12(0);
  let trHeightList = [];
  const containerHeight = ref12(0);
  const containerWidth = ref12(0);
  const startAndEndIndex = ref12([0, 15]);
  const tScroll = computed9(() => {
    const { scroll } = params.value;
    if (!scroll) return {};
    return {
      bufferSize: scroll.bufferSize || 10,
      isFixedRowHeight: scroll.isFixedRowHeight ?? false,
      rowHeight: scroll.rowHeight || 47,
      threshold: scroll.threshold || 100,
      type: scroll.type,
      fixedRows: scroll.fixedRows ?? [0, 0]
    };
  });
  const isVirtualScroll = computed9(() => {
    const { data } = params.value;
    return tScroll.value.type === "virtual" && tScroll.value.threshold < data.length;
  });
  function getVisibleRangeConfig() {
    const scrollTop = container.value?.scrollTop ?? 0;
    const fixedStart = tScroll.value.fixedRows[0];
    const prevBufferHeightList = [];
    let hiddenHeight = 0;
    let visibleStart = -1;
    let visibleEnd = -1;
    let totalHeight = 0;
    for (let i = 0, len = params.value.data.length; i < len; i++) {
      const rowHeight = trHeightList[i] ?? tScroll.value.rowHeight;
      totalHeight = totalHeight + rowHeight;
      if (totalHeight > scrollTop && visibleStart === -1) {
        visibleStart = i;
        if (visibleStart - tScroll.value.bufferSize > 0) {
          hiddenHeight = totalHeight - rowHeight - sum(prevBufferHeightList);
        }
      }
      if (visibleStart === -1) {
        prevBufferHeightList.push(rowHeight);
        if (prevBufferHeightList.length > tScroll.value.bufferSize) {
          prevBufferHeightList.shift();
        }
      }
      if (visibleEnd === -1 && (totalHeight > containerHeight.value + scrollTop || i === params.value.data.length - 1)) {
        visibleEnd = i;
      }
      if (visibleStart !== -1 && visibleEnd !== -1) {
        break;
      }
    }
    const startIndex = max([visibleStart - tScroll.value.bufferSize, 0]);
    const endIndex = min([visibleEnd + tScroll.value.bufferSize, params.value.data.length]);
    const stickyHeight = sum(trHeightList.slice(0, Math.min(startIndex, fixedStart)));
    return {
      startIndex,
      endIndex,
      translateY: hiddenHeight - stickyHeight
    };
  }
  const updateVisibleData = throttle(() => {
    const { startIndex, endIndex, translateY: translateYValue } = getVisibleRangeConfig();
    const fixedRows = tScroll.value.fixedRows;
    const [fixedStart, fixedEnd] = fixedRows;
    let fixedStartData = fixedStart ? params.value.data.slice(0, fixedStart) : [];
    if (fixedStart && startIndex < fixedStart) {
      fixedStartData = fixedStartData.slice(0, startIndex);
    }
    let fixedEndData = fixedEnd ? params.value.data.slice(params.value.data.length - fixedEnd) : [];
    const bottomStartIndex = endIndex - params.value.data.length + 1 + (fixedEnd ?? 0);
    if (fixedEnd && bottomStartIndex > 0) {
      fixedEndData = fixedEndData.slice(bottomStartIndex);
    }
    if (startAndEndIndex.value.join() !== [startIndex, endIndex].join() && startIndex >= 0) {
      translateY.value = translateYValue;
      visibleData.value = fixedStartData.concat(params.value.data.slice(startIndex, endIndex), fixedEndData);
      startAndEndIndex.value = [startIndex, endIndex];
    }
  }, 100);
  const handleRowMounted = (rowData) => {
    if (!isVirtualScroll.value || !rowData || tScroll.value.isFixedRowHeight || !container.value) return;
    const trHeight = rowData.ref.value?.getBoundingClientRect().height || tScroll.value.rowHeight;
    const rowIndex = rowData.data.VIRTUAL_SCROLL_INDEX;
    if (trHeightList[rowIndex] !== trHeight) {
      const diff = trHeight - trHeightList[rowIndex];
      trHeightList[rowIndex] = trHeight;
      scrollHeight.value = scrollHeight.value + diff;
    }
  };
  const handleScroll = () => {
    if (!isVirtualScroll.value) return;
    updateVisibleData();
  };
  const refreshVirtualScroll = ([{ contentRect }]) => {
    if (params.value.preventResizeRefresh) return;
    const maxScrollbarWidth = 16;
    if (Math.abs(contentRect.width - containerWidth.value) > maxScrollbarWidth && !!container.value) {
      container.value.scrollTop = 0;
      translateY.value = 0;
    }
    containerWidth.value = contentRect.width;
    containerHeight.value = contentRect.height;
  };
  const addIndexToData = (data) => {
    data.forEach((item, index) => {
      item["VIRTUAL_SCROLL_INDEX"] = index;
    });
  };
  const updateScrollTop = ({ index, top = 0, behavior }) => {
    const scrollTop = sum(trHeightList.slice(0, index + 1)) - top;
    container.value.scrollTo({
      top: scrollTop,
      behavior: behavior || "auto"
    });
  };
  const scrollToElement = (p) => {
    updateScrollTop(p);
    if (!tScroll.value.isFixedRowHeight) {
      const duration = p.time ?? 60;
      const timer = setTimeout(() => {
        updateScrollTop(p);
        clearTimeout(timer);
      }, duration);
    }
  };
  useResizeObserver(
    computed9(() => isVirtualScroll.value ? container.value : void 0),
    refreshVirtualScroll
  );
  watch7(
    () => [[...params.value.data], tScroll.value, isVirtualScroll.value, container.value],
    () => {
      if (!isVirtualScroll.value || !container.value) return;
      const { data } = params.value;
      addIndexToData(data);
      containerHeight.value = container.value.getBoundingClientRect().height;
      if (trHeightList.length !== params.value.data.length) {
        const initHeightList = Array.from(trHeightList);
        initHeightList.length = params.value.data.length;
        initHeightList.fill(tScroll.value.rowHeight || 47);
        trHeightList = initHeightList;
      }
      scrollHeight.value = sum(trHeightList);
      startAndEndIndex.value = [0, 0];
      updateVisibleData();
    },
    { immediate: true }
  );
  watch7(
    () => containerHeight.value,
    () => {
      updateVisibleData();
    }
  );
  return {
    visibleData,
    translateY,
    scrollHeight,
    isVirtualScroll,
    handleScroll,
    handleRowMounted,
    scrollToElement
  };
}

// packages/shared/hooks/useMutationObservable/index.ts
import { onBeforeUnmount as onBeforeUnmount5, onMounted as onMounted8, ref as ref13, watch as watch8 } from "vue";
import { debounce, isEqual } from "lodash-es";

// packages/shared/hooks/useVariables/index.ts
import { nextTick as nextTick3, ref as ref14 } from "vue";

// packages/common/js/common.ts
var CHECKED_CODE_REG = /^(Enter|Space)$/i;

// packages/shared/hooks/useEventForward/index.ts
import { computed as computed10 } from "vue";

// packages/components/tree/utils/adapt.ts
import { ref as ref21, reactive as reactive3, computed as computed14, watch as watch12, onMounted as onMounted12, toRefs as toRefs5, defineComponent as defineComponent6, TransitionGroup } from "vue";
import { CaretRightSmallIcon } from "tdesign-icons-vue-next";

// packages/components/checkbox/checkbox.tsx
import { defineComponent, ref as ref16, toRefs as toRefs2, inject as inject4, watch as watch10, computed as computed11, createVNode as _createVNode2 } from "vue";
import { isString as isString5 } from "lodash-es";

// packages/components/checkbox/props.ts
var props_default = {
  /** 用于标识是否为「全选选项」。单独使用无效，需在 CheckboxGroup 中使用 */
  checkAll: Boolean,
  /** 是否选中 */
  checked: {
    type: Boolean,
    default: void 0
  },
  modelValue: {
    type: Boolean,
    default: void 0
  },
  /** 是否选中，非受控属性 */
  defaultChecked: Boolean,
  /** 多选框内容，同 label */
  default: {
    type: [String, Function]
  },
  /** 是否禁用组件。如果父组件存在 CheckboxGroup，默认值由 CheckboxGroup.disabled 控制。优先级：Checkbox.disabled > CheckboxGroup.disabled > Form.disabled */
  disabled: {
    type: Boolean,
    default: void 0
  },
  /** 是否为半选 */
  indeterminate: Boolean,
  /** 主文案 */
  label: {
    type: [String, Function]
  },
  /** 是否启用懒加载。数据量大时建议开启；加载复杂内容或大量图片时建议开启 */
  lazyLoad: Boolean,
  /** HTML 元素原生属性 */
  name: {
    type: String,
    default: ""
  },
  /** 只读状态 */
  readonly: {
    type: Boolean,
    default: void 0
  },
  /** HTML 原生属性 */
  title: {
    type: String,
    default: ""
  },
  /** 多选框的值 */
  value: {
    type: [String, Number, Boolean]
  },
  /** 值变化时触发 */
  onChange: Function
};

// packages/components/checkbox/constants/index.ts
var CheckboxGroupInjectionKey = Symbol("CheckboxGroupProvide");

// packages/components/checkbox/hooks/useCheckboxLazyLoad.ts
import { onBeforeUnmount as onBeforeUnmount6, onMounted as onMounted9, ref as ref15, watch as watch9 } from "vue";
function useCheckboxLazyLoad(labelRef, lazyLoad) {
  const ioObserver = ref15();
  const showCheckbox = ref15(true);
  const handleLazyLoad = () => {
    if (!lazyLoad.value) return;
    showCheckbox.value = false;
    const io = observe(
      labelRef.value,
      null,
      () => {
        showCheckbox.value = true;
      },
      0
    );
    ioObserver.value = io;
  };
  onMounted9(handleLazyLoad);
  watch9([lazyLoad, labelRef], handleLazyLoad);
  onBeforeUnmount6(() => {
    if (!lazyLoad.value) return;
    ioObserver.value.unobserve(labelRef.value);
  });
  return {
    showCheckbox
  };
}
var useCheckboxLazyLoad_default = useCheckboxLazyLoad;

// packages/components/checkbox/hooks/useKeyboardEvent.ts
function useKeyboardEvent(handleChange) {
  const keyboardEventListener = (e) => {
    const isCheckedCode = CHECKED_CODE_REG.test(e.key) || CHECKED_CODE_REG.test(e.code);
    if (isCheckedCode) {
      e.preventDefault();
      const { disabled } = e.currentTarget.querySelector("input");
      !disabled && handleChange(e);
    }
  };
  const onCheckboxFocus = (e) => {
    e.currentTarget.addEventListener("keydown", keyboardEventListener);
  };
  const onCheckboxBlur = (e) => {
    e.currentTarget.removeEventListener("keydown", keyboardEventListener);
  };
  return {
    onCheckboxFocus,
    onCheckboxBlur
  };
}
var useKeyboardEvent_default = useKeyboardEvent;

// packages/components/checkbox/checkbox.tsx
var checkbox_default = defineComponent({
  name: "TCheckbox",
  props: {
    ...props_default,
    needRipple: Boolean,
    stopLabelTrigger: Boolean,
    index: Number,
    // 传递给 Checkbox 组件额外的数据
    data: Object
  },
  setup(props) {
    const labelRef = ref16();
    if (props.needRipple) {
      useRipple(labelRef);
    }
    const {
      STATUS
    } = useCommonClassName();
    const {
      checked,
      modelValue,
      lazyLoad,
      onChange: onChangeRef
    } = toRefs2(props);
    const [innerChecked, setInnerChecked] = useVModel(checked, modelValue, props.defaultChecked, onChangeRef, "checked");
    const checkboxGroupData = inject4(CheckboxGroupInjectionKey, void 0);
    const tName = ref16();
    watch10(() => [props.name, checkboxGroupData?.value.name].join("_"), () => {
      const name = props.name || checkboxGroupData?.value.name;
      if (name) {
        tName.value = name;
      }
    }, {
      immediate: true
    });
    const tChecked = ref16(false);
    const getChecked = () => {
      const {
        value,
        checkAll
      } = props;
      if (checkAll) return checkboxGroupData?.value.isCheckAll;
      return checkboxGroupData?.value ? checkboxGroupData.value.checkedValues.includes(value) : innerChecked.value;
    };
    watch10(() => [innerChecked.value, checkboxGroupData?.value.isCheckAll, checkboxGroupData?.value.checkedValues?.join(",")], () => {
      tChecked.value = getChecked();
    }, {
      immediate: true
    });
    const beforeDisabled = computed11(() => {
      if (!props.checkAll && !tChecked.value && checkboxGroupData?.value.maxExceeded) {
        return true;
      }
      return null;
    });
    const afterDisabled = computed11(() => {
      return checkboxGroupData?.value.disabled;
    });
    const isDisabled = useDisabled({
      beforeDisabled,
      afterDisabled
    });
    const afterReadonly = computed11(() => {
      return checkboxGroupData?.value.readonly;
    });
    const isReadonly = useReadonly({
      afterReadonly
    });
    const tIndeterminate = ref16(false);
    watch10(() => [props.checkAll, props.indeterminate, checkboxGroupData?.value.indeterminate], () => {
      tIndeterminate.value = props.checkAll ? checkboxGroupData?.value.indeterminate : props.indeterminate;
    }, {
      immediate: true
    });
    const COMPONENT_NAME = usePrefixClass("checkbox");
    const labelClasses = ref16({});
    watch10([tChecked, isDisabled, tIndeterminate], () => {
      labelClasses.value = [`${COMPONENT_NAME.value}`, {
        [STATUS.value.checked]: tChecked.value,
        [STATUS.value.disabled]: isDisabled.value,
        [STATUS.value.indeterminate]: tIndeterminate.value
      }];
    }, {
      immediate: true
    });
    const handleChange = (e) => {
      if (isReadonly.value || isDisabled.value) return;
      const checked2 = !tChecked.value;
      setInnerChecked(checked2, {
        e
      });
      if (checkboxGroupData?.value.handleCheckboxChange) {
        checkboxGroupData.value.onCheckedChange({
          checked: checked2,
          checkAll: props.checkAll,
          e,
          option: props
        });
      }
    };
    const renderContent = useContent();
    const handleLabelClick = (e) => {
      if (props.stopLabelTrigger) e.preventDefault();
    };
    const {
      showCheckbox
    } = useCheckboxLazyLoad_default(labelRef, lazyLoad);
    const {
      onCheckboxFocus,
      onCheckboxBlur
    } = useKeyboardEvent_default(handleChange);
    return () => {
      const titleAttr = isString5(props.title) && props.title ? props.title : null;
      return _createVNode2("label", {
        "ref": labelRef,
        "class": labelClasses.value,
        "tabindex": isDisabled.value ? void 0 : "0",
        "onFocus": onCheckboxFocus,
        "onBlur": onCheckboxBlur,
        "onClick": handleLabelClick,
        "title": titleAttr
      }, [!showCheckbox.value ? null : [_createVNode2("input", {
        "type": "checkbox",
        "tabindex": "-1",
        "class": `${COMPONENT_NAME.value}__former`,
        "disabled": isDisabled.value,
        "readonly": isReadonly.value,
        "indeterminate": tIndeterminate.value,
        "name": tName.value,
        "value": props.value ? props.value : void 0,
        "checked": tChecked.value,
        "onChange": handleChange,
        "onClick": (e) => e.stopPropagation(),
        "key": "input"
      }, null), _createVNode2("span", {
        "class": `${COMPONENT_NAME.value}__input`,
        "key": "input-span",
        "onClick": props.stopLabelTrigger && handleChange
      }, null), _createVNode2("span", {
        "class": `${COMPONENT_NAME.value}__label`,
        "key": "label"
      }, [renderContent("default", "label")])]]);
    };
  }
});

// packages/components/checkbox/group.tsx
import { defineComponent as defineComponent2, provide as provide3, computed as computed12, watchEffect, ref as ref17, toRefs as toRefs3, createVNode as _createVNode3 } from "vue";
import { isObject as isObject4, isUndefined, intersection } from "lodash-es";

// packages/components/checkbox/checkbox-group-props.ts
var checkbox_group_props_default = {
  /** 是否禁用组件。优先级：Form.disabled < CheckboxGroup.disabled < Checkbox.disabled */
  disabled: {
    type: Boolean,
    default: void 0
  },
  /** 是否启用懒加载。子组件 Checkbox 数据量大时建议开启；加载复杂内容或大量图片时建议开启 */
  lazyLoad: Boolean,
  /** 支持最多选中的数量 */
  max: {
    type: Number,
    default: void 0
  },
  /** 统一设置内部复选框 HTML 属性 */
  name: {
    type: String,
    default: ""
  },
  /** 以配置形式设置子元素。示例1：`['北京', '上海']` ，示例2: `[{ label: '全选', checkAll: true }, { label: '上海', value: 'shanghai' }]`。checkAll 值为 true 表示当前选项为「全选选项」 */
  options: {
    type: Array
  },
  /** 只读状态 */
  readonly: {
    type: Boolean,
    default: void 0
  },
  /** 选中值 */
  value: {
    type: Array,
    default: void 0
  },
  modelValue: {
    type: Array,
    default: void 0
  },
  /** 选中值，非受控属性 */
  defaultValue: {
    type: Array,
    default: () => []
  },
  /** 值变化时触发。`context.current` 表示当前变化的数据项，如果是全选则为空；`context.type` 表示引起选中数据变化的是选中或是取消选中，`context.option` 表示当前变化的数据项 */
  onChange: Function
};

// packages/components/checkbox/group.tsx
var group_default = defineComponent2({
  name: "TCheckboxGroup",
  props: checkbox_group_props_default,
  setup(props) {
    const COMPONENT_NAME = usePrefixClass("checkbox-group");
    const renderTNodeJSX = useTNodeJSX();
    const {
      isArray: isArray8
    } = Array;
    const {
      value,
      modelValue,
      onChange: onChangeRef
    } = toRefs3(props);
    const [rawValue, setRawValue] = useVModel(value, modelValue, props.defaultValue, onChangeRef);
    const innerValue = computed12(() => isArray8(rawValue.value) ? rawValue.value : []);
    const optionList = ref17([]);
    const intersectionLen = computed12(() => {
      const values = optionList.value.map((item) => item.value);
      const n = intersection(innerValue.value, values);
      return n.length;
    });
    const isCheckAll = computed12(() => {
      const optionItems = optionList.value.filter((item) => !item.disabled && !item.readonly && !item.checkAll).map((t2) => t2.value);
      const intersectionValues = intersection(optionItems, innerValue.value);
      return intersectionValues.length === optionItems.length;
    });
    const indeterminate = computed12(() => !isCheckAll.value && intersectionLen.value < optionList.value.length && intersectionLen.value !== 0);
    const maxExceeded = computed12(() => !isUndefined(props.max) && innerValue.value.length === props.max);
    watchEffect(() => {
      if (!props.options) return [];
      optionList.value = props.options.map((item) => {
        return isObject4(item) ? item : {
          label: String(item),
          value: item
        };
      });
    });
    const getAllCheckboxValue = () => {
      const checkAllVal = /* @__PURE__ */ new Set();
      const uncheckAllVal = /* @__PURE__ */ new Set();
      for (let i = 0, len = optionList.value.length; i < len; i++) {
        const item = optionList.value[i];
        if (item.checkAll) continue;
        if (item.disabled) {
          if (!innerValue.value.includes(item.value)) continue;
          else uncheckAllVal.add(item.value);
        }
        if (item.readonly) {
          if (!innerValue.value.includes(item.value)) continue;
          else uncheckAllVal.add(item.value);
        }
        checkAllVal.add(item.value);
        if (maxExceeded.value) break;
      }
      return {
        checkAllVal: [...checkAllVal],
        uncheckAllVal: [...uncheckAllVal]
      };
    };
    const onCheckAllChange = (checked, context) => {
      const {
        checkAllVal,
        uncheckAllVal
      } = getAllCheckboxValue();
      const value2 = checked ? checkAllVal : uncheckAllVal;
      setRawValue(value2, {
        e: context.e,
        type: checked ? "check" : "uncheck",
        current: void 0,
        option: void 0
      });
    };
    const handleCheckboxChange = (data) => {
      const currentValue = data.option.value;
      const val = [...innerValue.value];
      if (data.checked) {
        val.push(currentValue);
      } else {
        const i = val.indexOf(currentValue);
        val.splice(i, 1);
      }
      setRawValue(val, {
        e: data.e,
        current: data.option.value,
        option: data.option,
        type: data.checked ? "check" : "uncheck"
      });
    };
    const onCheckedChange = (p) => {
      const {
        checked,
        checkAll,
        e
      } = p;
      if (checkAll) {
        onCheckAllChange(checked, {
          e
        });
      } else {
        handleCheckboxChange(p);
      }
    };
    const getChildComponentSlots = useChildComponentSlots();
    const getOptionListBySlots = () => {
      const nodes = getChildComponentSlots("Checkbox");
      const arr = [];
      nodes?.forEach((node) => {
        const option = node.props;
        if (!option) return;
        if (option["check-all"] === "" || option["check-all"] === true) {
          option.checkAll = true;
        }
        arr.push(option);
      });
      return arr;
    };
    provide3(CheckboxGroupInjectionKey, computed12(() => ({
      name: props.name,
      isCheckAll: isCheckAll.value,
      checkedValues: innerValue.value,
      maxExceeded: maxExceeded.value,
      disabled: props.disabled,
      readonly: props.readonly,
      indeterminate: indeterminate.value,
      handleCheckboxChange,
      onCheckedChange
    })));
    return () => {
      let children = null;
      if (props.options?.length) {
        children = optionList.value?.map((option, index) => _createVNode3(checkbox_default, {
          "key": `${option.value || ""}${index}`,
          "lazyLoad": props.lazyLoad,
          ...option,
          "index": index,
          "checked": innerValue.value.includes(option.value),
          "data": option
        }, null));
      } else {
        const nodes = renderTNodeJSX("default");
        optionList.value = getOptionListBySlots();
        children = nodes;
      }
      return _createVNode3("div", {
        "class": COMPONENT_NAME.value,
        "role": "group",
        "aria-label": "checkbox-group"
      }, [children]);
    };
  }
});

// packages/components/checkbox/index.ts
var Checkbox = withInstall(checkbox_default);
var CheckboxGroup = withInstall(group_default);

// packages/components/loading/directive.ts
import { mapKeys, isEqual as isEqual2, isObject as isObject5 } from "lodash-es";

// packages/components/loading/plugin.tsx
import { createVNode, defineComponent as defineComponent5, h as h4, reactive as reactive2, render, ref as ref20 } from "vue";
import { merge as merge2 } from "lodash-es";

// packages/components/loading/loading.tsx
import { defineComponent as defineComponent4, ref as ref19, computed as computed13, watch as watch11, onMounted as onMounted11, toRefs as toRefs4, Teleport as Teleport2, createVNode as _createVNode5 } from "vue";

// packages/components/loading/icon/gradient.tsx
import { defineComponent as defineComponent3, onMounted as onMounted10, nextTick as nextTick4, ref as ref18, createVNode as _createVNode4 } from "vue";

// packages/common/js/utils/helper.ts
import { isArray as isArray6, isNull, isNumber, isString as isString6, isUndefined as isUndefined2 } from "lodash-es";
function getIEVersion() {
  if (typeof navigator === "undefined" || !navigator) return Number.MAX_SAFE_INTEGER;
  const { userAgent } = navigator;
  const isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1;
  const isIE11 = userAgent.indexOf("Trident") > -1 && userAgent.indexOf("rv:11.0") > -1;
  if (isIE) {
    const reIE = /MSIE (\d+\.\d+);/;
    const match = userAgent.match(reIE);
    if (!match) return -1;
    const fIEVersion = parseFloat(match[1]);
    return fIEVersion < 7 ? 6 : fIEVersion;
  }
  if (isIE11) {
    return 11;
  }
  return Number.MAX_SAFE_INTEGER;
}

// packages/common/js/loading/circle-adapter.ts
function circleAdapter(circleElem) {
  let basicStyle = {};
  if (!circleElem || typeof window === "undefined") {
    return;
  }
  const computedStyle = window.getComputedStyle?.(circleElem);
  const color = computedStyle?.color || "";
  const fontSize = computedStyle?.fontSize || "12px";
  const ua = window?.navigator?.userAgent;
  const isSafari = /Safari/.test(ua) && !/Chrome/.test(ua);
  const isIosWechat = /(?=.*iPhone)[?=.*MicroMessenger]/.test(ua) && !/Chrome/.test(ua);
  const isIpadWechat = /(?=.*iPad)[?=.*MicroMessenger]/.test(ua) && !/Chrome/.test(ua);
  if (isSafari || isIosWechat || isIpadWechat) {
    basicStyle = {
      transformOrigin: "0px 0px",
      transform: `scale(${parseInt(fontSize, 10) / 12})`
    };
  }
  if (color && getIEVersion() > 11) {
    const matched = color.match(/[\d.]+/g);
    const endColor = matched ? `rgba(${matched[0]}, ${matched[1]}, ${matched[2]}, 0)` : "";
    setStyle_default(circleElem, {
      ...basicStyle,
      background: `conic-gradient(from 90deg at 50% 50%,${endColor} 0deg, ${color} 360deg)`
    });
  } else {
    setStyle_default(circleElem, {
      ...basicStyle,
      background: ""
    });
  }
}

// packages/components/loading/icon/gradient.tsx
var gradient_default = defineComponent3({
  name: "TLoadingGradient",
  setup() {
    const classPrefix = usePrefixClass();
    const circleRef = ref18();
    onMounted10(() => {
      nextTick4(() => {
        circleAdapter(circleRef.value);
      });
    });
    return () => {
      const name = `${classPrefix.value}-loading__gradient`;
      const classes = [name, `${classPrefix.value}-icon-loading`];
      return _createVNode4("svg", {
        "class": classes,
        "viewBox": "0 0 12 12",
        "version": "1.1",
        "width": "1em",
        "height": "1em",
        "xmlns": "http://www.w3.org/2000/svg"
      }, [_createVNode4("foreignObject", {
        "x": "0",
        "y": "0",
        "width": "12",
        "height": "12"
      }, [_createVNode4("div", {
        "class": `${name}-conic`,
        "ref": circleRef
      }, null)])]);
    };
  }
});

// packages/components/loading/props.ts
var props_default2 = {
  /** 挂载元素，默认挂载到组件本身所在的位置。数据类型为 String 时，会被当作选择器处理，进行节点查询。示例：'body' 或 () => document.body */
  attach: {
    type: [String, Function],
    default: ""
  },
  /** 子元素 */
  content: {
    type: [String, Function]
  },
  /** 子元素，同 content */
  default: {
    type: [String, Function]
  },
  /** 延迟显示加载效果的时间，用于防止请求速度过快引起的加载闪烁，单位：毫秒 */
  delay: {
    type: Number,
    default: void 0
  },
  /** 是否显示为全屏加载 */
  fullscreen: Boolean,
  /** 加载指示符，值为 true 显示默认指示符，值为 false 则不显示，也可以自定义指示符 */
  indicator: {
    type: [Boolean, Function],
    default: true
  },
  /** 是否继承父元素颜色 */
  inheritColor: {
    type: Boolean,
    default: void 0
  },
  /** 是否处于加载状态 */
  loading: {
    type: Boolean,
    default: true
  },
  /** 防止滚动穿透，全屏加载模式有效 */
  preventScrollThrough: {
    type: Boolean,
    default: void 0
  },
  /** 是否需要遮罩层，遮罩层对包裹元素才有效 */
  showOverlay: {
    type: Boolean,
    default: void 0
  },
  /** 尺寸，示例：small/medium/large/12px/56px/0.3em */
  size: {
    type: String,
    default: void 0
  },
  /** 加载提示文案 */
  text: {
    type: [String, Function]
  },
  /** 消息通知层级，样式默认为 3500 */
  zIndex: {
    type: Number
  }
};

// packages/components/loading/loading.tsx
var useComponentClassName = () => {
  return {
    name: usePrefixClass("loading"),
    centerClass: usePrefixClass("loading--center"),
    fullscreenClass: usePrefixClass("loading__fullscreen"),
    lockClass: usePrefixClass("loading--lock"),
    overlayClass: usePrefixClass("loading__overlay"),
    relativeClass: usePrefixClass("loading__parent"),
    fullClass: usePrefixClass("loading--full"),
    inheritColorClass: usePrefixClass("loading--inherit-color")
  };
};
var loading_default = defineComponent4({
  name: "TLoading",
  inheritAttrs: false,
  props: props_default2,
  setup(props, {
    slots,
    attrs
  }) {
    const delayShowLoading = ref19(false);
    const {
      name,
      centerClass,
      fullscreenClass,
      lockClass,
      overlayClass,
      relativeClass,
      fullClass,
      inheritColorClass
    } = useComponentClassName();
    const classPrefix = usePrefixClass();
    const renderTNodeJSX = useTNodeJSX();
    const renderContent = useContent();
    const {
      SIZE
    } = useCommonClassName();
    const {
      globalConfig
    } = useConfig("loading");
    const delay = computed13(() => props.delay ?? globalConfig.value.delay);
    const size = computed13(() => props.size ?? globalConfig.value.size);
    const zIndex = computed13(() => props.zIndex ?? globalConfig.value.zIndex);
    const showOverlay = computed13(() => props.showOverlay ?? globalConfig.value.showOverlay);
    const inheritColor = computed13(() => props.inheritColor ?? globalConfig.value.inheritColor);
    const preventScrollThrough = computed13(() => props.preventScrollThrough ?? globalConfig.value.preventScrollThrough);
    const countDelay = () => {
      delayShowLoading.value = false;
      const timer = setTimeout(() => {
        delayShowLoading.value = true;
        clearTimeout(timer);
      }, delay.value);
    };
    const teleportElement = useTeleport(() => props.attach);
    const delayCounted = computed13(() => Boolean(!delay.value || delay.value && delayShowLoading.value));
    const styles = computed13(() => {
      const styles2 = {};
      if (zIndex.value !== void 0) {
        styles2.zIndex = zIndex.value;
      }
      if (!["small", "medium", "large"].includes(size.value)) {
        styles2["font-size"] = size.value;
      }
      return styles2;
    });
    const hasContent = computed13(() => Boolean(props.default || slots.default || props.content || slots.content));
    const lockFullscreen = computed13(() => preventScrollThrough.value && props.fullscreen);
    const showText = computed13(() => Boolean(props.text || slots.text));
    const showWrapLoading = computed13(() => hasContent.value && props.loading && delayCounted.value);
    const showFullScreenLoading = computed13(() => props.fullscreen && props.loading && delayCounted.value);
    const showAttachedLoading = computed13(() => props.attach && props.loading && delayCounted.value);
    const classes = computed13(() => {
      const baseClasses = [centerClass.value, getPropertyValFromObj(SIZE.value, size.value), {
        [inheritColorClass.value]: inheritColor.value
      }];
      const fullScreenClasses = [name.value, fullscreenClass.value, centerClass.value, overlayClass.value];
      return {
        baseClasses,
        attachClasses: baseClasses.concat([name.value, fullClass.value, {
          [overlayClass.value]: showOverlay.value
        }]),
        withContentClasses: baseClasses.concat([name.value, fullClass.value, {
          [overlayClass.value]: showOverlay.value
        }]),
        fullScreenClasses,
        normalClasses: baseClasses.concat([name.value])
      };
    });
    const {
      loading
    } = toRefs4(props);
    watch11([loading], ([isLoading]) => {
      if (isLoading) {
        countDelay();
        lockFullscreen.value && addClass(document.body, lockClass.value);
      } else {
        lockFullscreen.value && removeClass(document.body, lockClass.value);
      }
    });
    onMounted11(() => {
      delay.value && countDelay();
    });
    return () => {
      const {
        fullScreenClasses,
        baseClasses,
        withContentClasses,
        attachClasses,
        normalClasses
      } = classes.value;
      const defaultIndicator = _createVNode5(gradient_default, null, null);
      const indicator = loading.value && renderTNodeJSX("indicator", defaultIndicator);
      const text = showText.value && _createVNode5("div", {
        "class": `${classPrefix.value}-loading__text`
      }, [renderTNodeJSX("text")]);
      if (props.fullscreen) {
        if (!showFullScreenLoading.value || !props.loading) return null;
        return _createVNode5(Teleport2, {
          "disabled": !props.attach || !teleportElement.value,
          "to": teleportElement.value
        }, {
          default: () => [_createVNode5("div", {
            "class": fullScreenClasses,
            "style": styles.value,
            ...attrs
          }, [_createVNode5("div", {
            "class": baseClasses
          }, [indicator, text])])]
        });
      }
      if (hasContent.value) {
        return _createVNode5("div", {
          "class": relativeClass.value,
          ...attrs
        }, [renderContent("default", "content"), showWrapLoading.value && _createVNode5("div", {
          "class": withContentClasses,
          "style": styles.value
        }, [indicator, text])]);
      }
      if (props.attach) {
        if (!showAttachedLoading.value || !loading.value) return null;
        return _createVNode5(Teleport2, {
          "disabled": !props.attach || !teleportElement.value,
          "to": teleportElement.value
        }, {
          default: () => [_createVNode5("div", {
            "class": attachClasses,
            "style": styles.value,
            ...attrs
          }, [indicator, text])]
        });
      }
      return loading.value ? _createVNode5("div", {
        "class": normalClasses,
        "style": styles.value,
        ...attrs
      }, [indicator, text]) : null;
    };
  }
});

// packages/components/loading/plugin.tsx
var fullScreenLoadingInstance = null;
function mergeDefaultProps(props) {
  const options = merge2({
    fullscreen: false,
    attach: "body",
    loading: true,
    preventScrollThrough: true
  }, props);
  return options;
}
function createLoading(props, context) {
  const mergedProps = mergeDefaultProps(props);
  if (mergedProps.fullscreen && fullScreenLoadingInstance) {
    return fullScreenLoadingInstance;
  }
  const parentRelativeClass = ref20("");
  const lockClass = ref20("");
  const component = defineComponent5({
    setup() {
      const loadingOptions = reactive2(mergedProps);
      parentRelativeClass.value = usePrefixClass("loading__parent--relative").value;
      lockClass.value = usePrefixClass("loading--lock").value;
      const {
        globalConfig
      } = useConfig("loading");
      return () => h4(loading_default, {
        ...globalConfig.value,
        ...loadingOptions
      });
    }
  });
  const attach = getAttach(mergedProps.fullscreen ? "body" : mergedProps.attach);
  const instance = createVNode(component);
  if (context ?? LoadingPlugin._context) {
    instance.appContext = context ?? LoadingPlugin._context;
  }
  const wrapper = document.createElement("div");
  render(instance, wrapper);
  const lockFullscreen = mergedProps.preventScrollThrough && mergedProps.fullscreen;
  if (lockFullscreen) {
    addClass(document.body, lockClass.value);
  }
  if (attach) {
    addClass(attach, parentRelativeClass.value);
  } else {
    console.error("attach is not exist");
  }
  const loadingInstance = {
    hide: () => {
      removeClass(attach, parentRelativeClass.value);
      removeClass(document.body, lockClass.value);
      render(null, wrapper);
      wrapper.remove();
    }
  };
  return loadingInstance;
}
function produceLoading(props, context) {
  if (props === true) {
    fullScreenLoadingInstance = createLoading({
      fullscreen: true,
      loading: true,
      attach: "body",
      preventScrollThrough: true
    }, context);
    return fullScreenLoadingInstance;
  }
  if (props === false) {
    fullScreenLoadingInstance?.hide();
    fullScreenLoadingInstance = null;
    return;
  }
  return createLoading(props);
}
var LoadingPlugin = produceLoading;
LoadingPlugin.install = (app) => {
  app.config.globalProperties.$loading = produceLoading;
  LoadingPlugin._context = app._context;
};
var plugin_default = LoadingPlugin;

// packages/components/loading/directive.ts
var INSTANCE_KEY = Symbol("TdLoading");
var createInstance = (el, binding) => {
  const { fullscreen, inheritColor } = binding.modifiers;
  const options = {
    attach: () => el,
    fullscreen: fullscreen ?? false,
    inheritColor: inheritColor ?? false,
    loading: binding.value
  };
  if (isObject5(binding.value)) {
    mapKeys(binding.value, (value, key) => {
      options[key] = value;
    });
  }
  el[INSTANCE_KEY] = {
    options,
    instance: plugin_default(options)
  };
};
var vLoading = {
  mounted(el, binding) {
    if (binding.value) {
      createInstance(el, binding);
    }
  },
  updated(el, binding) {
    const instance = el[INSTANCE_KEY];
    const { value, oldValue } = binding;
    if (!isEqual2(value, oldValue)) {
      const loading = value?.loading ?? value;
      if (loading) {
        createInstance(el, binding);
      } else {
        instance?.instance.hide();
      }
    }
  },
  unmounted(el) {
    el[INSTANCE_KEY]?.instance.hide();
  }
};

// packages/components/loading/index.ts
var Loading = withInstall(loading_default, loading_default.name, { name: "loading", comp: vLoading });

// packages/common/js/tree/tree-node.ts
import { get as get2, isBoolean as isBoolean4, isFunction as isFunction7, isNil, isNull as isNull2, isNumber as isNumber2, uniqueId } from "lodash-es";

// packages/common/js/log/index.ts
var log_default2 = log_default;

// packages/common/js/tree/tree-node-model.ts
import { isUndefined as isUndefined3, isBoolean as isBoolean3, omit, get } from "lodash-es";
var nodeKey = "__tdesign_tree-node__";
var TreeNodeModel = class {
  [nodeKey];
  constructor(node) {
    this[nodeKey] = node;
  }
  get value() {
    const node = this[nodeKey];
    return node.value;
  }
  get label() {
    const node = this[nodeKey];
    return node.label;
  }
  get data() {
    const node = this[nodeKey];
    return node.data;
  }
  get actived() {
    const node = this[nodeKey];
    return node.actived;
  }
  get expanded() {
    const node = this[nodeKey];
    return node.expanded;
  }
  get checked() {
    const node = this[nodeKey];
    return node.checked;
  }
  get indeterminate() {
    const node = this[nodeKey];
    return node.indeterminate;
  }
  get loading() {
    const node = this[nodeKey];
    return node.loading;
  }
  get disabled() {
    const node = this[nodeKey];
    return node.isDisabled();
  }
  get level() {
    return this.getLevel();
  }
  /**
   * 获取节点所处层级
   * @return number 节点层级序号
   */
  getLevel() {
    const node = this[nodeKey];
    return node.getLevel();
  }
  /**
   * 获取节点在父节点的子节点列表中的位置
   * - 如果没有父节点，则获取节点在根节点列表的位置
   * @return number 节点位置序号
   */
  getIndex() {
    const node = this[nodeKey];
    return node.getIndex();
  }
  /**
   * 是否为兄弟节点中的第一个节点
   * @return boolean 是否为第一个节点
   */
  isFirst() {
    const node = this[nodeKey];
    return node.isFirst();
  }
  /**
   * 是否为兄弟节点中的最后一个节点
   * @return boolean 是否为最后一个节点
   */
  isLast() {
    const node = this[nodeKey];
    return node.isLast();
  }
  /**
   * 是否为叶子节点，叶子节点没有子节点
   * @return boolean 是否为叶子节点
   */
  isLeaf() {
    const node = this[nodeKey];
    return node.isLeaf();
  }
  /**
   * 在当前节点之前插入节点
   * @param {object} newData 要插入的节点或者数据
   * @return void
   */
  insertBefore(newData) {
    const node = this[nodeKey];
    return node.insertBefore(newData);
  }
  /**
   * 在当前节点之后插入节点
   * @param {object} newData 要插入的节点或者数据
   * @return void
   */
  insertAfter(newData) {
    const node = this[nodeKey];
    return node.insertAfter(newData);
  }
  /**
   * 追加节点数据
   * @param {object | object[]} data 节点数据
   * @return void
   */
  appendData(data) {
    const node = this[nodeKey];
    return node.append(data);
  }
  /**
   * 返回路径节点
   * - 路径节点包含自己在内
   * - 节点顺序与父级节点顺序相反，从根到当前
   * @return TreeNodeModel[] 路径节点数组
   */
  getPath() {
    const node = this[nodeKey];
    const nodes = node.getPath();
    return nodes.map((item) => item.getModel());
  }
  /**
   * 获取本节点的父节点
   * @return TreeNodeModel 父节点
   */
  getParent() {
    const node = this[nodeKey];
    return node.parent?.getModel();
  }
  /**
   * 获取所有父级节点
   * - 顺序为从当前到根
   * @return TreeNodeModel[] 父级节点数组
   */
  getParents() {
    const node = this[nodeKey];
    const nodes = node.getParents();
    return nodes.map((item) => item.getModel());
  }
  /**
   * 获取本节点的根节点
   * @return TreeNodeModel 根节点
   */
  getRoot() {
    const node = this[nodeKey];
    const root = node.getRoot();
    return root?.getModel();
  }
  /**
   * 获取所有兄弟节点，包含自己在内
   * @return TreeNodeModel[] 兄弟节点数组
   */
  getSiblings() {
    const node = this[nodeKey];
    const nodes = node.getSiblings();
    return nodes.map((item) => item.getModel());
  }
  /**
   * 获取当前节点的子节点
   * @param {boolean} deep 是否获取所有深层子节点
   * @return TreeNodeModel[] 子节点数组
   */
  getChildren(deep) {
    const node = this[nodeKey];
    let childrenModel = false;
    const { children } = node;
    if (Array.isArray(children)) {
      if (children.length > 0) {
        if (deep) {
          const nodes = node.walk();
          nodes.shift();
          childrenModel = nodes.map((item) => item.getModel());
        } else {
          childrenModel = children.map((item) => item.getModel());
        }
      } else {
        childrenModel = false;
      }
    } else if (isBoolean3(children)) {
      childrenModel = children;
    }
    return childrenModel;
  }
  /**
   * 移除节点
   * - 提供 value 参数，移除本节点子节点中的节点
   * - 不提供 value 参数，移除自己
   * @param {string} value 目标节点值
   * @return void
   */
  remove(value) {
    const node = this[nodeKey];
    if (!value) {
      node.remove();
      return;
    }
    const { tree } = node;
    const targetNode = tree.getNode(value);
    if (!targetNode) {
      log_default.warnOnce("Tree", `\`${value}\` is not exist`);
      return;
    }
    const parents = targetNode.getParents();
    const parentValues = parents.map((pnode) => pnode.value);
    if (parentValues.indexOf(node.value) < 0) {
      log_default.warnOnce("Tree", `\`${value}\` is not a childNode of current node`);
      return;
    }
    targetNode.remove();
  }
  /**
   * 设置本节点携带的元数据
   * @param {object} data 节点数据
   * @return void
   */
  setData(data) {
    const node = this[nodeKey];
    const syncAttrs = ["value", "label", "disabled"];
    const cleanData = omit(data, ["children", ...syncAttrs]);
    const { keys } = node.tree.config;
    syncAttrs.forEach((attr) => {
      const dataAttrValue = get(data, keys?.[attr] || attr);
      if (!isUndefined3(dataAttrValue)) cleanData[attr] = dataAttrValue;
    });
    Object.assign(node.data, cleanData);
    Object.assign(node, cleanData);
    node.update();
  }
};
function createNodeModel(node) {
  const model = new TreeNodeModel(node);
  return model;
}

// packages/common/js/tree/tree-node.ts
var { hasOwnProperty: hasOwnProperty2 } = Object.prototype;
var settableStatus = {
  expandMutex: null,
  activable: null,
  checkable: null,
  draggable: null,
  loading: false
};
var settableProps = Object.keys(settableStatus);
var syncableProps = [...settableProps, "actived", "expanded", "checked"];
var privateKey = "__tdesign_id__";
var TreeNode = class _TreeNode {
  // 节点隶属的树实例
  tree;
  // 节点私有 id，不接受外部传入，确保唯一性
  [privateKey];
  // 节点 id ，唯一标志
  value;
  // 节点文本
  label;
  // 节点数据
  data;
  // 父节点
  parent;
  // 子节点列表
  children;
  // 暴露的 treeNodeModel，这个对象的属性和 api 提供给用户使用
  model;
  // 是否为叶节点
  vmIsLeaf;
  // 是否为子节点中的第一个
  vmIsFirst;
  // 是否为子节点中的最后
  vmIsLast;
  // 节点是否是经过过滤剩下的
  vmIsRest;
  // 节点是否展示为锁定状态
  vmIsLocked;
  // 节点在视图上实际的展开状态
  expanded;
  // 展开时是否收起同级节点，对子节点生效
  expandMutex;
  // 节点在视图上实际的激活状态
  actived;
  // 是否可激活
  activable;
  // 是否可选中
  checkable;
  // 是否可选中的视图呈现
  vmCheckable;
  // 节点在视图上实际的选中态
  checked;
  // 节点实际是否为半选状态
  indeterminate;
  // 节点是否已禁用
  disabled;
  disableManually;
  // 节点是否可拖动
  draggable;
  // 节点是否可视
  visible;
  // 节点在树中的层级
  level;
  // 节点是否正在加载数据
  loading;
  constructor(tree, data, parent) {
    this.data = data;
    this.tree = tree;
    const config = tree.config || {};
    const prefix = config.prefix || "t";
    const keys = config.keys || {};
    const propChildren = keys.children || "children";
    const propLabel = keys.label || "label";
    const propValue = keys.value || "value";
    this.model = null;
    this.children = null;
    this.level = 0;
    this.vmCheckable = false;
    this.vmIsLeaf = false;
    this.vmIsFirst = false;
    this.vmIsLast = false;
    this.vmIsRest = false;
    this.vmIsLocked = false;
    this.visible = false;
    this.actived = false;
    this.checked = false;
    this.indeterminate = false;
    this.loading = false;
    this.expanded = config.expandAll;
    this.activable = null;
    this.checkable = null;
    this.expandMutex = null;
    this.draggable = null;
    this.disableManually = null;
    this[privateKey] = uniqueId(prefix);
    this.value = isNil(get2(data, propValue)) ? this[privateKey] : get2(data, propValue);
    const { nodeMap, privateMap } = tree;
    if (nodeMap.get(this.value)) {
      log_default2.warn("Tree", `Dulplicate value: ${this.value}`);
    }
    nodeMap.set(this.value, this);
    privateMap.set(this[privateKey], this);
    this.label = get2(data, propLabel) || "";
    const children = data[propChildren];
    if (children === true) {
      this.children = children;
    }
    if (parent && parent instanceof _TreeNode) {
      this.parent = parent;
    } else {
      this.parent = null;
    }
    syncableProps.forEach((prop) => {
      if (typeof data[prop] !== "undefined") {
        this[prop] = data[prop];
      }
    });
    this.initActived();
    this.initExpanded();
    if (Array.isArray(children)) {
      this.append(children);
    } else if (children === true && !config.lazy) {
      this.loadChildren();
    }
    if (this.isLeaf()) {
      this.expanded = false;
      this.tree.expandedMap.delete(this.value);
    }
    this.initChecked();
    this.updateChecked();
    this.update();
    tree.reflow(this);
  }
  /* ------ 状态初始化 ------ */
  /**
   * 初始化选中态
   * @return void
   */
  initChecked() {
    const { tree, value, parent } = this;
    const { checkedMap } = tree;
    const { checkStrictly } = tree.config;
    if (this.checked) {
      checkedMap.set(value, true);
    }
    if (!checkStrictly && parent?.checked) {
      checkedMap.set(value, true);
    }
  }
  /**
   * 初始化节点展开状态
   * @return void
   */
  initExpanded() {
    const { tree } = this;
    let { expanded } = this;
    const { config } = tree;
    if (isNumber2(config.expandLevel) && this.getLevel() < config.expandLevel) {
      tree.expandedMap.set(this.value, true);
      expanded = true;
    }
    if (this.children === true && config.lazy) {
      expanded = false;
    }
    if (expanded) {
      tree.expandedMap.set(this.value, true);
    } else {
      tree.expandedMap.delete(this.value);
    }
    this.expanded = expanded;
  }
  /**
   * 初始化节点激活状态
   * @return void
   */
  initActived() {
    const { tree, actived } = this;
    if (actived && this.isActivable()) {
      tree.activedMap.set(this.value, true);
    }
  }
  /* ------ 节点操作 ------ */
  /**
   * 追加节点数据
   * @param {object | object[]} data 节点数据
   * @return void
   */
  append(data) {
    const list = [];
    if (!Array.isArray(data)) {
      list.push(data);
    } else {
      list.push(...data);
    }
    if (list.length <= 0) {
      return;
    }
    const wasLeaf = this.isLeaf();
    if (!Array.isArray(this.children)) {
      this.children = [];
    }
    const { children, tree } = this;
    list.forEach((item) => {
      let node = null;
      if (item instanceof _TreeNode) {
        node = item;
        node.appendTo(this.tree, this);
      } else {
        node = new _TreeNode(this.tree, item, this);
        children.push(node);
      }
    });
    if (wasLeaf && tree.config.expandAll && !this.isLeaf()) {
      tree.expandedMap.set(this.value, true);
      this.expanded = true;
    }
    tree.reflow(this);
    this.updateRelated();
  }
  /**
   * 将当前节点追加到某个父节点的子节点列表中
   * @param {TreeStore} tree 目标树
   * @param {TreeNode} [parent] 目标父节点
   * @param {number} [index] 预期在子节点列表中的位置
   * @return void
   */
  appendTo(tree, parent, index) {
    const parentNode = parent;
    let targetIndex = -1;
    if (isNumber2(index)) {
      targetIndex = index;
    }
    const targetParents = parentNode?.getParents() || [];
    const includeCurrent = targetParents.some((pnode) => pnode === this);
    if (includeCurrent) {
      throw new Error("\u65E0\u6CD5\u5C06\u7236\u8282\u70B9\u63D2\u5165\u5230\u5B50\u8282\u70B9");
    }
    if (parentNode === this) {
      throw new Error("\u65E0\u6CD5\u5C06\u8282\u70B9\u63D2\u5165\u5230\u672C\u8282\u70B9");
    }
    if (Array.isArray(parentNode?.children)) {
      const targetPosNode = parentNode?.children[targetIndex];
      if (targetPosNode && targetPosNode === this) {
        return;
      }
    }
    let siblings = null;
    if (parentNode instanceof _TreeNode) {
      if (!Array.isArray(parentNode?.children)) {
        parentNode.children = [];
      }
      siblings = parent.children;
    } else {
      siblings = tree.children;
    }
    if (!Array.isArray(siblings)) {
      throw new Error("\u65E0\u6CD5\u63D2\u5165\u5230\u76EE\u6807\u4F4D\u7F6E\uFF0C\u53EF\u63D2\u5165\u7684\u8282\u70B9\u5217\u8868\u4E0D\u5B58\u5728");
    }
    const prevLength = siblings.length;
    const prevIndex = this.getIndex();
    this.remove();
    if (isNumber2(index)) {
      let targetIndex2 = index;
      if (parentNode === this.parent) {
        const curLength = siblings.length;
        if (curLength < prevLength && prevIndex <= targetIndex2) {
          targetIndex2 -= 1;
        }
      }
      siblings.splice(targetIndex2, 0, this);
    } else {
      siblings.push(this);
    }
    this.parent = parentNode;
    const nodes = this.walk();
    nodes.forEach((item) => {
      const node = item;
      node.tree = tree;
      tree.nodeMap.set(node.value, node);
      tree.privateMap.set(node[privateKey], node);
      if (node.expanded) {
        tree.expandedMap.set(node.value, true);
      }
    });
    const updateNodes = parentNode?.walk() || tree.children.map((item) => item.walk()).flat();
    updateNodes.forEach((node) => {
      node.update();
      node.updateChecked();
    });
    tree.reflow();
  }
  /**
   * 插入一个节点或者数据到到同级节点的目标位置
   * @param {TreeNode | object} item 要插入的节点或者数据
   * @param {number} [index] 预期在子节点列表中的位置
   * @return void
   */
  insert(item, index) {
    const { tree, parent } = this;
    const siblings = this.getSiblings();
    let node = null;
    if (item instanceof _TreeNode) {
      node = item;
      node.appendTo(tree, parent, index);
    } else if (item) {
      node = new _TreeNode(tree, item, parent);
      if (isNumber2(index)) {
        siblings.splice(index, 0, node);
      }
      siblings.forEach((sibling) => {
        sibling.update();
      });
    }
    tree.reflow();
  }
  /**
   * 在当前节点之前插入节点
   * @param {TreeNode | object} newData 要插入的节点或者数据
   * @return void
   */
  insertBefore(newData) {
    const index = this.getIndex();
    this.insert(newData, index);
  }
  /**
   * 在当前节点之后插入节点
   * @param {TreeNode | object} newData 要插入的节点或者数据
   * @return void
   */
  insertAfter(newData) {
    const index = this.getIndex();
    this.insert(newData, index + 1);
  }
  /**
   * 从当前树中移除本节点
   * @return void
   */
  remove() {
    const { tree } = this;
    const nodes = this.walk();
    const siblings = this.getSiblings();
    const index = this.getIndex();
    if (Array.isArray(siblings)) {
      siblings.splice(index, 1);
    }
    nodes.forEach((node) => {
      node.clean();
    });
    siblings.forEach((node) => {
      node.update();
    });
    this.updateParents();
    tree.reflow();
  }
  /**
   * 清除本节点与当前树的关系
   * @return void
   */
  clean() {
    const { tree, value } = this;
    tree.activedMap.delete(value);
    tree.checkedMap.delete(value);
    tree.expandedMap.delete(value);
    tree.nodeMap.delete(value);
    tree.filterMap.delete(value);
    tree.privateMap.delete(this[privateKey]);
  }
  /**
   * 异步加载子节点
   * @return Promise<void>
   */
  async loadChildren() {
    const config = get2(this, "tree.config") || {};
    if (this.children === true && !this.loading) {
      if (isFunction7(config.load)) {
        this.loading = true;
        this.update();
        let list = [];
        list = await config.load(this);
        this.tree.emit("load", {
          node: this,
          data: list
        });
        this.loading = false;
        if (Array.isArray(list) && list.length > 0) {
          this.append(list);
        } else {
          this.children = false;
        }
        this.update();
      }
    }
  }
  /**
   * 设置节点状态
   */
  set(item) {
    const { tree } = this;
    const keys = Object.keys(item);
    keys.forEach((key) => {
      if (hasOwnProperty2.call(settableStatus, key) || key === "label") {
        this[key] = item[key];
      }
      if (key === "disabled") {
        this.setDisabled(item[key]);
      }
    });
    tree.updated(this);
  }
  /* ------ 节点获取 ------- */
  /**
   * 获取本节点的父节点
   * @return TreeNode 父节点
   */
  getParent() {
    return this.parent;
  }
  /**
   * 获取所有父级节点
   * - 顺序为从当前到根
   * @return TreeNode[] 父级节点数组
   */
  getParents() {
    const parents = [];
    let node = this.parent;
    while (node) {
      parents.push(node);
      node = node.parent;
    }
    return parents;
  }
  /**
   * 获取所有兄弟节点，包含自己在内
   * @return TreeNode[] 兄弟节点数组
   */
  getSiblings() {
    const { parent, tree } = this;
    let list = [];
    if (parent) {
      if (Array.isArray(parent.children)) {
        list = parent.children;
      }
    } else if (tree) {
      list = tree.children;
    }
    return list;
  }
  /**
   * 获取当前节点的子节点
   * @param {boolean} deep 是否获取所有深层子节点
   * @return TreeNodeModel[] 子节点数组
   */
  getChildren(deep) {
    let childrenModel = false;
    const { children } = this;
    if (Array.isArray(children)) {
      if (children.length > 0) {
        if (deep) {
          const nodes = this.walk();
          nodes.shift();
          childrenModel = nodes.map((item) => item.getModel());
        } else {
          childrenModel = children.map((item) => item.getModel());
        }
      } else {
        childrenModel = false;
      }
    } else if (isBoolean4(children)) {
      childrenModel = children;
    }
    return childrenModel;
  }
  /**
   * 获取本节点的根节点
   * @return TreeNode 根节点
   */
  getRoot() {
    const parents = this.getParents();
    return parents[parents.length - 1] || null;
  }
  /**
   * 获取节点在父节点的子节点列表中的位置
   * - 如果没有父节点，则获取节点在根节点列表的位置
   * @return number 节点位置序号
   */
  getIndex() {
    const list = this.getSiblings();
    return list.indexOf(this);
  }
  /**
   * 返回路径节点
   * - 路径节点包含自己在内
   * - 节点顺序与父级节点顺序相反，从根到当前
   * @return TreeNode[] 路径节点数组
   */
  getPath() {
    const nodes = this.getParents();
    nodes.unshift(this);
    return nodes.reverse();
  }
  /**
   * 获取节点所在层级
   * @return number 层级序号
   */
  getLevel() {
    const parents = this.getParents();
    return parents.length;
  }
  /* ------ 节点状态判断 ------ */
  /**
   * 判断节点是否被过滤
   * @return boolean 是否被过滤方法命中
   */
  isRest() {
    const { config, filterMap, hasFilter } = this.tree;
    let rest = false;
    if (hasFilter) {
      const nodeModel = this.getModel();
      rest = config.filter(nodeModel);
    }
    if (rest) {
      filterMap.set(this.value, true);
    } else if (filterMap.get(this.value)) {
      filterMap.delete(this.value);
    }
    return rest;
  }
  /**
   * 判断节点是否可见
   * @return boolean 是否可见
   */
  isVisible() {
    const { nodeMap, hasFilter, config } = this.tree;
    const { allowFoldNodeOnFilter } = config;
    let visible = true;
    if (!nodeMap.get(this.value)) {
      return false;
    }
    if (hasFilter && !allowFoldNodeOnFilter) {
      visible = this.vmIsLocked || this.vmIsRest;
      return visible;
    }
    let expandVisible = true;
    const parents = this.getParents();
    if (parents.length > 0) {
      expandVisible = parents.every((node) => node.expanded);
    }
    if (hasFilter) {
      visible = expandVisible && (this.vmIsRest || this.vmIsLocked);
    } else {
      visible = expandVisible;
    }
    return visible;
  }
  /**
   * 判断节点为逻辑禁用状态，不包含过滤锁定状态
   * - 优先级：Tree 配置 > checkStrictly > 手动 > 节点 data > disableCheck
   */
  isDisabledState() {
    const { tree, parent } = this;
    const { config } = tree;
    const { checkStrictly, disabled, disableCheck, keys = {} } = config;
    if (disabled) return true;
    if (!checkStrictly && parent?.isDisabled() && !this.vmIsRest) return true;
    if (typeof this.disableManually === "boolean") return this.disableManually;
    const propDisabled = keys.disabled || "disabled";
    const state = get2(this.data, propDisabled);
    if (typeof state === "boolean") return state;
    if (disableCheck === true) return true;
    if (typeof disableCheck === "function") {
      const stateCheck = disableCheck(this.getModel());
      if (typeof stateCheck === "boolean") {
        return stateCheck;
      }
    }
    return false;
  }
  /**
   * 判断节点是否呈现为禁用态，包含过滤锁定状态
   * @return boolean 是否被禁用
   */
  isDisabled() {
    const { tree } = this;
    const { hasFilter, config } = tree;
    const { allowFoldNodeOnFilter } = config;
    if (hasFilter && !allowFoldNodeOnFilter && this.vmIsLocked && !this.vmIsRest) {
      return true;
    }
    return this.isDisabledState();
  }
  /**
   * 判断节点是否能拖拽
   * @return boolean 是否能拖拽
   */
  isDraggable() {
    let state = !!get2(this, "tree.config.draggable");
    if (typeof this.draggable === "boolean") {
      state = this.draggable;
    }
    return state;
  }
  /**
   * 判断子节点是否互斥展开
   * @return boolean 子节点是否互斥展开
   */
  isExpandMutex() {
    let state = !!get2(this, "tree.config.expandMutex");
    if (typeof this.expandMutex === "boolean") {
      state = this.expandMutex;
    }
    return state;
  }
  /**
   * 节点是否可被激活
   * @return boolean 是否可被激活
   */
  isActivable() {
    let state = !!get2(this, "tree.config.activable");
    if (typeof this.activable === "boolean") {
      state = this.activable;
    }
    return state;
  }
  /**
   * 节点是否可选
   * @return boolean 是否可选
   */
  isCheckable() {
    let state = !!get2(this, "tree.config.checkable");
    if (typeof this.checkable === "boolean") {
      state = this.checkable;
    }
    return state;
  }
  /**
   * 节点是否被激活
   * @param {Map} [map] 预设激活节点 map, 用于计算节点在预期环境中的激活状态
   * @return boolean 是否被激活
   */
  isActived(map) {
    const { tree, value } = this;
    const activedMap = map || tree.activedMap;
    return !!(tree.nodeMap.get(value) && activedMap.get(value));
  }
  /**
   * 节点是否已展开
   * @param {Map} [map] 预设展开节点 map, 用于计算节点在预期环境中的展开状态
   * @return boolean 是否已展开
   */
  isExpanded(map) {
    const { tree, value, vmIsLocked } = this;
    const { hasFilter, config } = tree;
    const { allowFoldNodeOnFilter } = config;
    if (hasFilter && !allowFoldNodeOnFilter && vmIsLocked) return true;
    const expandedMap = map || tree.expandedMap;
    return !!(tree.nodeMap.get(value) && expandedMap.get(value));
  }
  /**
   * 节点是否被选中
   * @param {Map} [map] 预设选中节点 map, 用于计算节点在预期环境中的选中态
   * @return boolean 是否被选中
   */
  isChecked(map) {
    const { children, tree, value } = this;
    const { checkStrictly, valueMode } = tree.config;
    if (!tree.nodeMap.get(value)) return false;
    if (!this.isCheckable()) return false;
    const checkedMap = map || tree.checkedMap;
    if (checkStrictly) {
      return !!checkedMap.get(value);
    }
    let checked = false;
    if (checkedMap.get(value) && // 如果 valueMode 为 all、parentFirst，则视为选中
    (valueMode !== "onlyLeaf" || // 如果 valueMode 为 onlyLeaf 并且当前节点是叶子节点，则视为选中
    this.isLeaf())) {
      return true;
    }
    if (Array.isArray(children) && children.length > 0) {
      const enabledChildren = children.filter((node) => !node.isDisabled());
      checked = enabledChildren.length > 0 && enabledChildren.every((node) => node.isChecked(checkedMap));
    } else {
      const parents = this.getParents();
      checked = !this.isDisabled() && parents.some((node) => checkedMap.get(node.value));
    }
    return checked;
  }
  /**
   * 是否为半选状态
   * @return boolean 是否为半选状态
   */
  isIndeterminate() {
    const { children, tree, value } = this;
    const { checkStrictly } = tree.config;
    if (!tree.nodeMap.get(value)) return false;
    if (!this.isCheckable()) return false;
    if (checkStrictly) return false;
    if (!Array.isArray(children)) return false;
    let childChecked = null;
    const indeterminate = children.some((node) => {
      if (node.isDisabled()) return false;
      if (node.isIndeterminate()) {
        return true;
      }
      if (isNull2(childChecked)) {
        childChecked = node.isChecked();
      }
      if (childChecked !== node.isChecked()) {
        return true;
      }
      return false;
    });
    return indeterminate;
  }
  /**
   * 是否为兄弟节点中的第一个节点
   * @return boolean 是否为第一个节点
   */
  isFirst() {
    const siblings = this.getSiblings();
    return siblings[0] === this;
  }
  /**
   * 是否为兄弟节点中的最后一个节点
   * @return boolean 是否为最后一个节点
   */
  isLast() {
    const siblings = this.getSiblings();
    return siblings[siblings.length - 1] === this;
  }
  /**
   * 是否为叶子节点，叶子节点没有子节点
   * @return boolean 是否为叶子节点
   */
  isLeaf() {
    let isLeaf = false;
    if (Array.isArray(this.children)) {
      isLeaf = this.children.length <= 0;
    } else {
      isLeaf = !this.children;
    }
    return isLeaf;
  }
  /* ------ 节点状态切换 ------ */
  /**
   * 锁定节点，解锁节点
   * - 搜索过滤节点时，路径节点需要固定呈现，视其为锁定态
   * @param {boolean} lockState 锁定状态
   * @return void
   */
  lock(lockState) {
    this.vmIsLocked = lockState;
    this.expanded = this.isExpanded();
    this.visible = this.isVisible();
  }
  /**
   * 节点展开关闭后需要调用的状态检查函数
   * @return void
   */
  afterExpanded() {
    this.update();
    if (this.expanded && this.children === true) {
      this.loadChildren();
    }
    this.updateChildren();
  }
  /**
   * 切换节点展开状态
   * - 用于受控逻辑处理
   * - 仅返回预期状态值数组，不直接操作状态
   * @return string[] 当前树展开的节点值数组
   */
  toggleExpanded(opts) {
    return this.setExpanded(!this.isExpanded(), opts);
  }
  /**
   * 设置节点展开状态
   * @param {boolean} expanded 节点展开状态
   * @param {object} [opts] 操作选项
   * @param {boolean} [opts.directly=false] 是否直接操作节点状态
   * @return string[] 当前树展开的节点值数组
   */
  setExpanded(expanded, opts) {
    const { tree } = this;
    const { config } = tree;
    const options = {
      directly: false,
      ...opts
    };
    let map = tree.expandedMap;
    if (!options.directly) {
      map = new Map(tree.expandedMap);
    }
    if (expanded) {
      const shouldExpandNodes = [];
      shouldExpandNodes.push(this);
      if (config.expandParent) {
        this.getParents().forEach((node) => {
          shouldExpandNodes.push(node);
        });
      }
      shouldExpandNodes.forEach((node) => {
        let isExpandMutex = false;
        if (node.parent) {
          isExpandMutex = node.parent.isExpandMutex();
        } else {
          isExpandMutex = tree?.config?.expandMutex;
        }
        if (isExpandMutex) {
          const siblings = node.getSiblings();
          siblings.forEach((snode) => {
            map.delete(snode.value);
            snode.update();
            snode.updateChildren();
          });
        }
        map.set(node.value, true);
        node.update();
        node.updateChildren();
      });
    } else {
      map.delete(this.value);
    }
    if (options.directly) {
      this.afterExpanded();
    }
    return tree.getExpanded(map);
  }
  /**
   * 切换节点激活状态
   * - 用于受控逻辑处理
   * - 仅返回预期状态值数组，不直接操作状态
   * @return string[] 当前树激活的节点值数组
   */
  toggleActived(opts) {
    return this.setActived(!this.isActived(), opts);
  }
  /**
   * 设置节点激活状态
   * @param {boolean} actived 节点激活状态
   * @param {object} [opts] 操作选项
   * @param {boolean} [opts.directly=false] 是否直接操作节点状态
   * @return string[] 当前树激活的节点值数组
   */
  setActived(actived, opts) {
    const { tree } = this;
    const options = {
      // 为 true, 为 UI 操作，状态变更受 disabled 影响
      // 为 false, 为值操作, 状态变更不受 disabled 影响
      isAction: true,
      // 为 true, 直接操作节点状态
      // 为 false, 返回预期状态
      directly: false,
      ...opts
    };
    const config = tree.config || {};
    let map = tree.activedMap;
    if (!options.directly) {
      map = new Map(tree.activedMap);
    }
    if (options.isAction && this.isDisabledState()) {
      return tree.getActived(map);
    }
    if (this.isActivable()) {
      if (actived) {
        const prevKeys = Array.from(map.keys());
        if (!config.activeMultiple) {
          map.clear();
        }
        prevKeys.forEach((value) => {
          const node = tree.getNode(value);
          node?.update();
        });
        map.set(this.value, true);
      } else {
        map.delete(this.value);
      }
    }
    this.update();
    return tree.getActived(map);
  }
  /**
   * 是否存在未选中的未禁用子节点
   * @return boolean 未选中的未禁用子节点存在与否
   */
  hasEnableUnCheckedChild() {
    const { children } = this;
    if (!Array.isArray(children) || children.length <= 0) {
      return false;
    }
    let state = false;
    children.some((child) => {
      if (child.isDisabledState()) return false;
      if (child.isChecked()) return false;
      if (child.isIndeterminate()) {
        if (child.hasEnableUnCheckedChild()) {
          state = true;
          return true;
        }
        return false;
      }
      state = true;
      return true;
    });
    return state;
  }
  /**
   * 切换节点选中状态
   * - 用于受控逻辑处理
   * - 仅返回预期状态值数组，不直接操作状态
   * @return string[] 当前树选中的节点值数组
   */
  toggleChecked(opts) {
    if (this.isIndeterminate()) {
      const expectState = this.hasEnableUnCheckedChild();
      return this.setChecked(expectState, opts);
    }
    return this.setChecked(!this.isChecked(), opts);
  }
  /**
   * 设置节点选中状态
   * - 节点 UI 操作时调用这个方法
   * - 节点设置自身状态时调用这个方法
   * @param {boolean} checked 节点选中状态
   * @param {object} [opts] 操作选项
   * @param {boolean} [opts.isAction=true] 是否为 UI 动作
   * @param {boolean} [opts.directly=false] 是否直接操作节点状态
   * @return string[] 当前树选中的节点值数组
   */
  setChecked(checked, opts) {
    const { tree } = this;
    const config = tree.config || {};
    const options = {
      // 为 true, 为 UI 操作，状态变更受 disabled 影响
      // 为 false, 为值操作, 状态变更不受 disabled 影响
      isAction: true,
      // 为 true, 直接操作节点状态
      // 为 false, 返回预期状态
      directly: false,
      ...opts
    };
    let map = tree.checkedMap;
    if (!options.directly) {
      map = new Map(tree.checkedMap);
    }
    if (!this.isCheckable()) {
      return tree.getChecked(map);
    }
    if (options.isAction && this.isDisabledState()) {
      return tree.getChecked(map);
    }
    if (checked === this.isChecked()) {
      const shouldSet = this.isIndeterminate() && !this.hasEnableUnCheckedChild();
      if (!shouldSet) {
        return tree.getChecked(map);
      }
    }
    if (checked) {
      map.set(this.value, true);
    } else {
      map.delete(this.value);
    }
    if (config.checkStrictly) {
      if (options.directly) {
        this.updateChecked();
      }
    } else {
      this.spreadChildrenChecked(checked, map, options);
      this.spreadParentChecked(checked, map, options);
      if (options.directly) {
        const relatedNodes = tree.getRelatedNodes([this.value], {
          reverse: true
        });
        relatedNodes.forEach((node) => {
          node.updateChecked();
        });
      }
    }
    return tree.getChecked(map);
  }
  // 选中态向上游扩散
  spreadParentChecked(checked, map, opts) {
    const options = {
      isAction: true,
      directly: false,
      ...opts
    };
    if (!this.isCheckable()) return;
    const { children } = this;
    if (Array.isArray(children) && children.length > 0) {
      map.delete(this.value);
    }
    const { parent } = this;
    if (!parent) return;
    parent.spreadParentChecked(checked, map, options);
  }
  // 选中态向下游扩散
  spreadChildrenChecked(checked, map, opts) {
    const options = {
      isAction: true,
      directly: false,
      ...opts
    };
    if (!this.isCheckable()) return;
    if (options.isAction && this.isDisabledState()) return;
    const { children } = this;
    if (!Array.isArray(children)) return;
    if (children.length <= 0) return;
    map.delete(this.value);
    children.forEach((node) => {
      if (options.isAction && node.isDisabledState()) return;
      if (checked) {
        map.set(node.value, true);
      } else {
        map.delete(node.value);
      }
      node.spreadChildrenChecked(checked, map, options);
    });
  }
  /**
   * 设置节点禁用状态
   */
  setDisabled(disabled) {
    if (!this.tree.config.checkStrictly && this.parent?.isDisabled()) return;
    this.disableManually = disabled;
    if (!this.tree.config.checkStrictly) {
      this.getParents().forEach((node) => this.tree.checkedMap.delete(node.value));
    }
    this.update();
    this.updateChildren();
    this.updateParents();
  }
  /* ------ 节点状态更新 ------ */
  /**
   * 更新节点当前状态，将节点放到延时更新检查队列
   * @return void
   */
  update() {
    this.level = this.getLevel();
    this.vmIsFirst = this.isFirst();
    this.vmIsLast = this.isLast();
    this.vmIsLeaf = this.isLeaf();
    this.vmCheckable = this.isCheckable();
    this.vmIsRest = this.isRest();
    this.actived = this.isActived();
    this.expanded = this.isExpanded();
    this.visible = this.isVisible();
    this.disabled = this.isDisabled();
    this.tree.updated(this);
  }
  /**
   * 更新节点选中态
   * @return void
   */
  updateChecked() {
    const { tree, value } = this;
    const { checkedMap } = tree;
    this.checked = this.isChecked();
    this.indeterminate = this.isIndeterminate();
    if (this.checked) {
      checkedMap.set(value, true);
    }
    tree.updated(this);
  }
  /**
   * 更新所有子节点状态
   * - 不包含自己
   * @return void
   */
  updateChildren() {
    this.spreadChildren((node) => {
      if (node === this) return;
      node.update();
      node.updateChecked();
    });
  }
  /**
   * 更新所有父级节点状态
   * - 不包含自己
   * @return void
   */
  updateParents() {
    this.spreadParents((node) => {
      if (node === this) return;
      node.update();
      node.updateChecked();
    });
  }
  /**
   * 更新上下游相关节点状态
   * - 包含自己
   * @return void
   */
  updateRelated() {
    const { tree } = this;
    const relatedNodes = tree.getRelatedNodes([this.value]);
    relatedNodes.forEach((node) => {
      node.update();
      node.updateChecked();
    });
  }
  /* ------ 节点遍历 ------ */
  /**
   * 获取包含自己在内所有的子节点
   * - 包含自己
   * @return TreeNode[] 遍历结果节点数组
   */
  walk() {
    const list = [];
    this.spreadChildren((node) => {
      list.push(node);
    });
    return list;
  }
  /**
   * 向下遍历操作
   * - 包含自己
   * @return void
   */
  spreadChildren(fn) {
    fn(this);
    const { children } = this;
    if (Array.isArray(children) && children.length > 0) {
      children.forEach((node) => {
        node?.spreadChildren(fn);
      });
    }
  }
  /**
   * 向上遍历操作
   * - 包含自己
   * @return void
   */
  spreadParents(fn) {
    fn(this);
    const { parent } = this;
    if (!parent) return;
    parent?.spreadParents(fn);
  }
  /**
   * 获取节点封装对象
   * - TreeNode 对象 => TypeTreeNodeModel 对象
   * - TypeTreeNodeModel 用于封装 treeNode 对外暴露的 api
   * - 用户仅可操作经过封装的对象，减少了对外暴露的 api，利于代码重构
   * @return TypeTreeNodeModel 节点封装对象
   */
  getModel() {
    let { model } = this;
    if (!model) {
      model = createNodeModel(this);
      this.model = model;
    }
    return model;
  }
};

// packages/components/tree/utils/adapt.ts
var onDrag = {
  default: void 0
};
var isVueNext = true;
var TreeItemDefinition = {
  name: "TTreeNode",
  inject: {
    onDrag
  }
};
function useRipple2(el) {
}
function getCreateElement(h6) {
  if (h6) {
  }
  return Vue.h;
}
function getScopedSlots(instance) {
  return instance.$slots;
}
function useVModel2(props, refsProps, propName = "value", defaultPropName = "defaultValue", eventPropName = "onChange", eventName = "change") {
  if (eventName) {
  }
  const { modelValue } = refsProps;
  let vm;
  if (propName === "value") {
    vm = useVModel(refsProps[propName], modelValue, props[defaultPropName], refsProps[eventPropName], propName);
  } else {
    vm = useDefaultValue(refsProps[propName], props[defaultPropName], refsProps[eventPropName], propName);
  }
  return vm;
}

// packages/components/tree/hooks/useDraggable.ts
import { throttle as throttle2 } from "lodash-es";
function useDraggable(state) {
  const { treeItemRef } = state;
  const dragStates = reactive3({
    isDragOver: false,
    isDragging: false,
    dropPosition: 0 /* Inside */
  });
  const updateDropPosition = (dragEvent) => {
    const rootNode = treeItemRef.value;
    if (!rootNode) return;
    const rect = rootNode?.getBoundingClientRect?.();
    const offsetY = window.scrollY + rect.top;
    const { pageY } = dragEvent;
    const gapHeight = rect.height / 4;
    const diff = pageY - offsetY;
    if (diff < gapHeight) {
      dragStates.dropPosition = -1 /* Before */;
    } else if (diff < rect.height - gapHeight) {
      dragStates.dropPosition = 0 /* Inside */;
    } else {
      dragStates.dropPosition = 1 /* After */;
    }
  };
  const setDragStatus = (status, dragEvent) => {
    const { node, treeScope } = state;
    const { drag } = treeScope;
    if (!drag) return;
    switch (status) {
      case "dragStart":
        dragStates.isDragging = true;
        dragStates.dropPosition = 0 /* Inside */;
        drag.handleDragStart?.({ node, dragEvent });
        break;
      case "dragEnd":
        dragStates.isDragging = false;
        dragStates.isDragOver = false;
        dragStates.dropPosition = 0 /* Inside */;
        throttleUpdateDropPosition.cancel();
        drag.handleDragEnd?.({ node, dragEvent });
        break;
      case "dragOver":
        dragStates.isDragOver = true;
        throttleUpdateDropPosition(dragEvent);
        drag.handleDragOver?.({ node, dragEvent });
        break;
      case "dragLeave":
        dragStates.isDragOver = false;
        dragStates.dropPosition = 0 /* Inside */;
        throttleUpdateDropPosition.cancel();
        drag.handleDragLeave?.({ node, dragEvent });
        break;
      case "drop":
        drag.handleDrop?.({ node, dropPosition: dragStates.dropPosition, dragEvent });
        dragStates.isDragOver = false;
        throttleUpdateDropPosition.cancel();
        break;
      default:
        break;
    }
  };
  const handleDragStart = (evt) => {
    const { node } = state;
    if (!node.isDraggable()) return;
    evt.stopPropagation();
    setDragStatus("dragStart", evt);
    try {
      evt.dataTransfer?.setData("text/plain", "");
    } catch (e) {
    }
  };
  const handleDragEnd = (evt) => {
    const { node } = state;
    if (!node.isDraggable()) return;
    evt.stopPropagation();
    setDragStatus("dragEnd", evt);
  };
  const handleDragOver = (evt) => {
    const { node } = state;
    if (!node.isDraggable()) return;
    evt.stopPropagation();
    evt.preventDefault();
    setDragStatus("dragOver", evt);
  };
  const handleDragLeave = (evt) => {
    const { node } = state;
    if (!node.isDraggable()) return;
    evt.stopPropagation();
    setDragStatus("dragLeave", evt);
  };
  const handleDrop = (evt) => {
    const { node } = state;
    if (!node.isDraggable()) return;
    evt.stopPropagation();
    evt.preventDefault();
    setDragStatus("drop", evt);
  };
  const throttleUpdateDropPosition = throttle2((dragEvent) => {
    updateDropPosition(dragEvent);
  });
  return {
    dragStates,
    handleDragStart,
    handleDragEnd,
    handleDragOver,
    handleDragLeave,
    handleDrop
  };
}

// packages/components/tree/utils/index.ts
import { camelCase as camelCase2 } from "lodash-es";
function emitEvent(props, context, evtName, ...args) {
  const apiName = camelCase2(`on-${evtName}`);
  evtName.replace(/^on/, "").toLowerCase();
  if (typeof props[apiName] === "function") {
    props[apiName](...args);
  }
  if (!isVueNext) {
    context.emit(evtName, ...args);
  }
}
function getParentsToRoot(element, root) {
  const list = [];
  let el = element;
  while (el && el.parentNode) {
    list.push(el);
    if (el === root) {
      break;
    }
    el = el.parentNode;
  }
  return list;
}
function getParentMarks(name, element, root) {
  const list = getParentsToRoot(element, root);
  return list.map((el) => {
    const mark = {
      name,
      value: el?.getAttribute(name) || "",
      el
    };
    return mark;
  }).filter((mark) => mark.value);
}
function getMark(name, element, root) {
  const list = getParentMarks(name, element, root);
  const info = list.pop() || null;
  return info;
}
function pathMatchClass(name, element, root) {
  const list = getParentsToRoot(element, root);
  const rs = list.some((el) => el.classList.contains(name));
  return rs;
}
function getTNode(prop, options) {
  let tnode = null;
  let item = null;
  const conf = {
    ...options
  };
  if (typeof prop === "function") {
    item = prop(conf.createElement, conf.node?.getModel());
  } else if (typeof prop === "string") {
    item = prop;
  }
  if (typeof item === "string") {
    tnode = item;
  } else if (item) {
    tnode = item;
  }
  return tnode;
}
function isTreeNodeValue(item) {
  return typeof item === "string" || typeof item === "number";
}
function getNode(store, item) {
  let node = null;
  let val = null;
  if (typeof item === "string" || typeof item === "number") {
    val = item;
  } else if (item && isTreeNodeValue(item.value)) {
    val = item.value;
  }
  node = store.getNode(val);
  return node;
}

// packages/components/tree/hooks/useDragHandle.ts
function useDragHandle(state) {
  const { props, context, scope, store } = state;
  let dragNode = null;
  const handleDragStart = (state2) => {
    const { dragEvent, node } = state2;
    dragNode = node;
    const ctx = {
      node: node.getModel(),
      e: dragEvent
    };
    emitEvent(props, context, "drag-start", ctx);
  };
  const handleDragEnd = (state2) => {
    const { dragEvent, node } = state2;
    dragNode = node;
    const ctx = {
      node: node.getModel(),
      e: dragEvent
    };
    emitEvent(props, context, "drag-end", ctx);
  };
  const handleDragOver = (state2) => {
    const { dragEvent, node } = state2;
    const ctx = {
      node: node.getModel(),
      e: dragEvent
    };
    emitEvent(props, context, "drag-over", ctx);
  };
  const handleDragLeave = (state2) => {
    const { dragEvent, node } = state2;
    const ctx = {
      node: node.getModel(),
      e: dragEvent
    };
    emitEvent(props, context, "drag-leave", ctx);
  };
  const handleDrop = (state2) => {
    const { dragEvent, node, dropPosition } = state2;
    if (node.value === dragNode.value || node.getParents().some((_node) => _node.value === dragNode.value)) return;
    const ctx = {
      dropNode: node.getModel(),
      dragNode: dragNode.getModel(),
      dropPosition,
      e: dragEvent
    };
    if (props.allowDrop?.(ctx) === false) return;
    const nodes = store.getNodes();
    nodes.some((_node) => {
      if (_node.value === node.value) {
        if (dropPosition === 0 /* Inside */) {
          dragNode.appendTo(store, _node);
        } else if (dropPosition === -1 /* Before */) {
          node.insertBefore(dragNode);
        } else {
          node.insertAfter(dragNode);
        }
        return true;
      }
      return false;
    });
    emitEvent(props, context, "drop", ctx);
  };
  const drag = {
    handleDragStart,
    handleDragEnd,
    handleDragOver,
    handleDragLeave,
    handleDrop
  };
  scope.drag = drag;
  return {
    drag
  };
}

// packages/components/tree/hooks/useTreeAction.ts
function useTreeAction(state) {
  const treeState = state;
  const { store } = treeState;
  const componentName = usePrefixClass("tree").value;
  const [tValue, setTValue] = state.vmValue;
  const [tActived, setTActived] = state.vmActived;
  const [tExpanded, setTExpanded] = state.vmExpanded;
  const setExpanded = (item, isExpanded) => {
    const node = getNode(store, item);
    const mouseEvent = treeState.mouseEvent;
    const evtCtx = {
      node: node.getModel(),
      e: mouseEvent,
      trigger: "setItem"
    };
    if (mouseEvent) {
      evtCtx.trigger = "node-click";
      const target = mouseEvent.target;
      const currentTarget = mouseEvent.currentTarget;
      if (pathMatchClass(`${componentName}__icon`, target, currentTarget)) {
        evtCtx.trigger = "icon-click";
      }
    }
    const expanded = node.setExpanded(isExpanded, {
      directly: true
    });
    setTExpanded(expanded, evtCtx);
    if (evtCtx.trigger !== "setItem") {
      store.replaceExpanded(tExpanded.value || []);
    }
    return expanded;
  };
  const toggleExpanded = (item) => {
    const node = getNode(store, item);
    if (!node.children) return;
    return setExpanded(node, !node.isExpanded());
  };
  const setActived = (item, isActived) => {
    const node = getNode(store, item);
    const mouseEvent = treeState.mouseEvent;
    const evtCtx = {
      node: node.getModel(),
      e: mouseEvent,
      trigger: "setItem"
    };
    if (mouseEvent) {
      evtCtx.trigger = "node-click";
    }
    const actived = node.setActived(isActived, {
      isAction: evtCtx.trigger === "node-click",
      directly: true
    });
    setTActived(actived, evtCtx);
    if (evtCtx.trigger !== "setItem") {
      store.replaceActived(tActived.value || []);
    }
    return actived;
  };
  const toggleActived = (item) => {
    const node = getNode(store, item);
    return setActived(node, !node.isActived());
  };
  const setChecked = (item, isChecked, ctx) => {
    const node = getNode(store, item);
    const mouseEvent = ctx?.e;
    const evtCtx = {
      node: node.getModel(),
      e: mouseEvent,
      trigger: "setItem"
    };
    if (mouseEvent) {
      evtCtx.trigger = "node-click";
    }
    const checked = node.setChecked(isChecked, {
      isAction: evtCtx.trigger === "node-click",
      directly: true
    });
    setTValue(checked, evtCtx);
    if (evtCtx.trigger !== "setItem") {
      store.replaceChecked(tValue.value || []);
    }
    return checked;
  };
  const toggleChecked = (item, ctx) => {
    const node = getNode(store, item);
    if (node.isIndeterminate()) {
      const expectState = node.hasEnableUnCheckedChild();
      return setChecked(node, expectState, ctx);
    }
    return setChecked(node, !node.isChecked(), ctx);
  };
  return {
    setExpanded,
    toggleExpanded,
    setActived,
    toggleActived,
    setChecked,
    toggleChecked
  };
}

// packages/components/tree/hooks/useTreeNodes.tsx
import { createVNode as _createVNode11 } from "vue";

// packages/components/tree/hooks/useItemState.ts
function useItemState(props, context) {
  const refProps = toRefs5(props);
  const treeItemRef = ref21(null);
  const { treeScope } = props;
  const { store } = treeScope;
  const node = store.privateMap.get(props.itemKey);
  const state = {
    stateId: props.stateId,
    props,
    context,
    treeScope,
    refProps,
    node,
    treeItemRef
  };
  return {
    state
  };
}

// packages/components/tree/hooks/useTreeItem.tsx
import { createVNode as _createVNode10 } from "vue";

// packages/components/tree/hooks/useItemEvents.ts
function useItemEvents(state) {
  const { context } = state;
  const classPrefix = usePrefixClass().value;
  const handleChange = (_, ctx) => {
    const { node } = state;
    const event = new Event("change");
    const evtContext = {
      event,
      node
    };
    context.emit("change", evtContext, ctx);
  };
  let clicked = false;
  const handleClick = (evt) => {
    const { node, treeScope } = state;
    const { treeProps = {} } = treeScope;
    const { expandOnClickNode } = treeProps;
    const srcTarget = evt.target;
    const isBranchTrigger = node.children && expandOnClickNode && (srcTarget.className === `${classPrefix}-checkbox__input` || srcTarget.tagName.toLowerCase() === "input");
    if (clicked || isBranchTrigger) return;
    clicked = true;
    setTimeout(() => {
      clicked = false;
    });
    if (expandOnClickNode && node.children && srcTarget.className?.indexOf?.(`${classPrefix}-tree__label`) !== -1)
      evt.preventDefault();
    const evtContext = {
      mouseEvent: evt,
      event: evt,
      node,
      path: node.getPath()
    };
    context.emit("click", evtContext);
  };
  return {
    handleChange,
    handleClick
  };
}

// packages/components/tree/hooks/useRenderIcon.tsx
import { createVNode as _createVNode6 } from "vue";
function useRenderIcon(state) {
  const classPrefix = usePrefixClass().value;
  const componentName = usePrefixClass("tree").value;
  const getFolderIcon = (h6) => {
    const {
      CaretRightSmallIcon: CaretRightSmallIcon2
    } = useGlobalIcon({
      CaretRightSmallIcon
    });
    return _createVNode6(CaretRightSmallIcon2, null, null);
  };
  const handleMousedown = (evt) => {
    evt.preventDefault();
  };
  const renderIcon = (h6) => {
    const {
      node,
      treeScope
    } = state;
    const {
      scopedSlots
    } = treeScope;
    const treeProps = treeScope?.treeProps || {};
    const {
      icon
    } = treeProps;
    let isDefaultIcon = false;
    let iconNode = null;
    if (icon === true) {
      if (scopedSlots?.icon) {
        iconNode = scopedSlots.icon({
          node: node?.getModel()
        });
      } else if (!node.vmIsLeaf) {
        isDefaultIcon = true;
        iconNode = getFolderIcon(h6);
        if (node.loading && node.expanded) {
          iconNode = _createVNode6(Loading, null, null);
        }
      } else {
        iconNode = "";
      }
    } else if (icon) {
      iconNode = getTNode(icon, {
        createElement: h6,
        node
      });
    }
    const wrapIconNode = _createVNode6("span", {
      "class": [`${componentName}__icon`, `${classPrefix}-folder-icon`, isDefaultIcon ? `${componentName}__icon--default` : ""],
      "trigger": "expand",
      "ignore": "active",
      "onmousedown": handleMousedown
    }, [iconNode]);
    return wrapIconNode;
  };
  return {
    renderIcon
  };
}

// packages/components/tree/hooks/useRenderLabel.tsx
import { isVNode as _isVNode, createVNode as _createVNode7 } from "vue";
import { isBoolean as isBoolean5 } from "lodash-es";
function _isSlot(s) {
  return typeof s === "function" || Object.prototype.toString.call(s) === "[object Object]" && !_isVNode(s);
}
function useRenderLabel(state) {
  const classPrefix = usePrefixClass().value;
  const componentName = usePrefixClass("tree").value;
  const {
    handleChange
  } = useItemEvents(state);
  const renderLabel = (h6) => {
    const {
      node,
      treeScope
    } = state;
    const {
      scopedSlots,
      treeProps = {}
    } = treeScope;
    const {
      label,
      expandOnClickNode
    } = treeProps;
    const checkProps = treeProps?.checkProps || {};
    let labelNode = null;
    if (label === true) {
      if (scopedSlots?.label) {
        labelNode = scopedSlots.label({
          node: node?.getModel()
        });
      } else {
        labelNode = node.label || "";
      }
    } else {
      labelNode = getTNode(label, {
        createElement: h6,
        node
      });
    }
    const labelClasses = [`${componentName}__label`, {
      [`${classPrefix}-is-active`]: node.isActivable() ? node.actived : false
    }];
    const shouldStopLabelTrigger = computed14(() => {
      const isNormalBranchNode = Array.isArray(node.children) && node.children?.length > 0;
      const isLazyLoadChildBranchNode = isBoolean5(node.children) && node.children;
      const isBranchNode = isNormalBranchNode || isLazyLoadChildBranchNode;
      return expandOnClickNode && isBranchNode;
    });
    if (node.vmCheckable) {
      let checkboxDisabled = false;
      if (node.vmIsLocked && !node.vmIsRest) {
        checkboxDisabled = true;
      }
      if (node.isDisabled()) {
        checkboxDisabled = true;
      }
      const _labelNode = /* @__PURE__ */ (function() {
        return labelNode;
      })();
      labelNode = _createVNode7(Checkbox, {
        "class": labelClasses,
        "checked": node.checked,
        "indeterminate": node.indeterminate,
        "name": String(node.value),
        "onChange": handleChange,
        "stopLabelTrigger": shouldStopLabelTrigger.value,
        ...checkProps,
        "disabled": checkboxDisabled,
        "title": node.label
      }, _isSlot(labelNode) ? labelNode : {
        default: () => [_labelNode]
      });
    } else {
      const inner = _createVNode7("span", {
        "style": "position: relative"
      }, [labelNode]);
      labelNode = node.isActivable() ? _createVNode7("span", {
        "key": "1",
        "ref": "label",
        "class": labelClasses,
        "title": node.label
      }, [inner]) : _createVNode7("span", {
        "key": "2",
        "class": labelClasses,
        "title": node.label
      }, [inner]);
    }
    return labelNode;
  };
  return {
    renderLabel
  };
}

// packages/components/tree/hooks/useRenderLine.tsx
import { createVNode as _createVNode8 } from "vue";
function useRenderLine(state) {
  const componentName = usePrefixClass("tree").value;
  const renderLine = (h6) => {
    const {
      node,
      treeScope
    } = state;
    const {
      scopedSlots
    } = treeScope;
    const treeProps = treeScope?.treeProps || {};
    const {
      line
    } = treeProps;
    const iconVisible = !!treeProps.icon;
    let lineNode = null;
    if (line === true) {
      if (scopedSlots?.line) {
        lineNode = scopedSlots.line({
          node: node?.getModel()
        });
      } else if (node.parent && node.tree) {
        const {
          vmIsLeaf,
          vmIsFirst,
          level
        } = node;
        const lineClasses = [];
        lineClasses.push(`${componentName}__line`);
        if (vmIsLeaf || !iconVisible) {
          lineClasses.push(`${componentName}__line--leaf`);
        }
        if (vmIsFirst && iconVisible) {
          lineClasses.push(`${componentName}__line--first`);
        }
        const shadowStyles = [];
        const parents = node.getParents();
        parents.pop();
        parents.forEach((pnode, index) => {
          if (!pnode.vmIsLast) {
            shadowStyles.push(`calc(-${index + 1} * var(--space)) 0 var(--color)`);
          }
        });
        const styles = {
          "--level": level ? String(level) : void 0,
          "box-shadow": shadowStyles.join(",")
        };
        lineNode = _createVNode8("span", {
          "class": lineClasses,
          "style": styles
        }, null);
      }
    } else {
      lineNode = getTNode(line, {
        createElement: h6,
        node
      });
    }
    return lineNode;
  };
  return {
    renderLine
  };
}

// packages/components/tree/hooks/useRenderOperations.tsx
import { createVNode as _createVNode9 } from "vue";
function useRenderOperations(state) {
  const componentName = usePrefixClass("tree").value;
  const renderOperations = (h6) => {
    const {
      node,
      treeScope
    } = state;
    const {
      scopedSlots
    } = treeScope;
    const treeProps = treeScope?.treeProps || {};
    const {
      operations
    } = treeProps;
    let opNode = null;
    if (scopedSlots?.operations) {
      opNode = scopedSlots.operations({
        node: node?.getModel()
      });
    } else {
      opNode = getTNode(operations, {
        createElement: h6,
        node
      });
    }
    if (opNode) {
      const _opNode = /* @__PURE__ */ (function() {
        return opNode;
      })();
      opNode = // TODO: 这里最好修改一下，改成 data-ignore 之类的
      // @ts-ignore
      _createVNode9("span", {
        "class": `${componentName}__operations`,
        "ignore": "active,expand"
      }, [opNode]);
    }
    return opNode;
  };
  return {
    renderOperations
  };
}

// packages/components/tree/hooks/useTreeItem.tsx
import { onUpdated as onUpdated2 } from "vue";
function useTreeItem(state) {
  const {
    treeScope,
    treeItemRef
  } = state;
  const {
    virtualConfig,
    treeContentRef,
    scrollProps
  } = treeScope;
  const classPrefix = usePrefixClass().value;
  const componentName = usePrefixClass("tree").value;
  const {
    handleClick
  } = useItemEvents(state);
  const {
    renderIcon
  } = useRenderIcon(state);
  const {
    renderLabel
  } = useRenderLabel(state);
  const {
    renderLine
  } = useRenderLine(state);
  const {
    renderOperations
  } = useRenderOperations(state);
  const {
    dragStates,
    handleDragStart,
    handleDragEnd,
    handleDragOver,
    handleDragLeave,
    handleDrop
  } = useDraggable(state);
  const {
    hasLazyLoadHolder,
    tRowHeight
  } = useLazyLoad(treeContentRef, treeItemRef, reactive3({
    ...scrollProps?.value
  }));
  function tryNotifyVirtualScrollRowUpdate() {
    const {
      node
    } = state;
    const isVirtual = virtualConfig?.isVirtualScroll.value;
    if (isVirtual) {
      const timer = setTimeout(() => {
        virtualConfig.handleRowMounted({
          ref: treeItemRef,
          data: node
        });
        clearTimeout(timer);
      }, 100);
    }
  }
  onMounted12(() => {
    tryNotifyVirtualScrollRowUpdate();
  });
  onUpdated2(() => {
    tryNotifyVirtualScrollRowUpdate();
  });
  const getItemStyles = () => {
    const {
      node
    } = state;
    const {
      level
    } = node;
    const levelStyle = `--level: ${level};`;
    const strStyle = `${levelStyle}`;
    return strStyle;
  };
  const getItemClassList = () => {
    const {
      node
    } = state;
    const {
      isDragOver,
      isDragging,
      dropPosition
    } = dragStates;
    const list = [];
    list.push(`${componentName}__item`);
    list.push({
      [`${componentName}__item--open`]: node.expanded,
      [`${classPrefix}-is-active`]: node.isActivable() ? node.actived : false,
      [`${classPrefix}-is-disabled`]: node.isDisabled()
    });
    list.push({
      [`${componentName}__item--draggable`]: !node.isDisabled() && node.isDraggable()
    });
    if (node.visible) {
      list.push(`${componentName}__item--visible`);
    } else {
      list.push(`${componentName}__item--hidden`);
    }
    if (node.vmIsLocked) {
      list.push(`${componentName}__item--locked`);
    }
    if (node.vmIsRest) {
      list.push(`${componentName}__item--matched`);
    }
    list.push({
      [`${componentName}__item--dragging`]: isDragging,
      [`${componentName}__item--tip-top`]: isDragOver && dropPosition < 0,
      [`${componentName}__item--tip-bottom`]: isDragOver && dropPosition > 0,
      [`${componentName}__item--tip-highlight`]: !isDragging && isDragOver && dropPosition === 0
    });
    return list;
  };
  const renderItem = (h6) => {
    const itemNodes = [];
    const iconNode = renderIcon(h6);
    const lineNode = renderLine(h6);
    if (lineNode) {
      itemNodes.push(lineNode);
    }
    if (iconNode) {
      itemNodes.push(iconNode);
    }
    const labelNode = renderLabel(h6);
    if (labelNode) {
      itemNodes.push(labelNode);
    }
    const opNode = renderOperations(h6);
    if (opNode) {
      itemNodes.push(opNode);
    }
    return itemNodes;
  };
  const renderItemNode = (h6) => {
    const {
      node,
      props
    } = state;
    if (!node) return null;
    const {
      level,
      value
    } = node;
    const styles = getItemStyles();
    const classList = getItemClassList();
    const treeState = state;
    treeState.stateId = props.stateId;
    const itemNode = _createVNode10("div", {
      "ref": "treeItemRef",
      "class": classList,
      "data-value": value,
      "data-level": level,
      "style": styles,
      "onClick": (evt) => handleClick(evt),
      "draggable": !node.isDisabled() && node.isDraggable(),
      "onDragstart": (evt) => handleDragStart(evt),
      "onDragend": (evt) => handleDragEnd(evt),
      "onDragover": (evt) => handleDragOver(evt),
      "onDragleave": (evt) => handleDragLeave(evt),
      "onDrop": (evt) => handleDrop(evt)
    }, [hasLazyLoadHolder.value ? [_createVNode10("div", null, null)] : renderItem(h6)]);
    return itemNode;
  };
  return {
    hasLazyLoadHolder,
    tRowHeight,
    renderItemNode
  };
}

// packages/components/tree/tree-item.tsx
var treeItemProps = {
  stateId: {
    type: String
  },
  itemKey: {
    type: String
  },
  rowIndex: {
    type: Number
  },
  treeScope: {
    type: Object
  }
};
var tree_item_default = defineComponent6({
  props: treeItemProps,
  ...TreeItemDefinition,
  setup(props, context) {
    const {
      state
    } = useItemState(props, context);
    const {
      treeItemRef
    } = state;
    const label = ref21();
    useRipple2(label);
    const {
      renderItemNode
    } = useTreeItem(state);
    return {
      treeItemRef,
      renderItemNode
    };
  },
  render(h6) {
    const createElement = getCreateElement(h6);
    if (typeof this.renderItemNode === "function") {
      return this.renderItemNode(createElement);
    }
    return null;
  }
});

// packages/components/tree/hooks/useTreeEvents.ts
function useTreeEvents(state) {
  const treeState = state;
  const { props, context } = treeState;
  const { toggleExpanded, toggleActived, toggleChecked } = useTreeAction(state);
  const handleClick = (evtState) => {
    const { mouseEvent, event, node } = evtState;
    if (!node || !mouseEvent) return;
    treeState.mouseEvent = mouseEvent;
    let shouldExpand = props.expandOnClickNode;
    let shouldActive = !props.disabled && !node.disabled && node.isActivable();
    let isRightClick = false;
    ["trigger", "ignore"].forEach((markName) => {
      const mark = getMark(markName, event.target, event.currentTarget);
      const markValue = mark?.value || "";
      if (markValue.indexOf("expand") >= 0) {
        if (markName === "trigger") {
          shouldExpand = true;
          isRightClick = true;
        } else if (markName === "ignore") {
          shouldExpand = false;
        }
      }
      if (markValue.indexOf("active") >= 0) {
        if (markName === "ignore") {
          shouldActive = false;
        }
      }
    });
    if (shouldExpand) {
      toggleExpanded(node);
      if (isRightClick) return;
    }
    if (shouldActive) {
      toggleActived(node);
    }
    const evtCtx = {
      node: node.getModel(),
      e: mouseEvent
    };
    emitEvent(props, context, "click", evtCtx);
    treeState.mouseEvent = null;
  };
  const handleChange = (evtState, ctx) => {
    const { disabled } = props;
    const { node } = evtState;
    if (!node || disabled || node.disabled || !node.isCheckable()) {
      return;
    }
    toggleChecked(node, ctx);
  };
  return {
    handleChange,
    handleClick
  };
}

// packages/components/tree/hooks/useTreeNodes.tsx
function useTreeNodes(state) {
  const {
    store,
    scope,
    allNodes,
    nodes,
    virtualConfig
  } = state;
  const {
    handleClick,
    handleChange
  } = useTreeEvents(state);
  const nodesEmpty = ref21(false);
  const cacheMap = /* @__PURE__ */ new Map();
  const refresh = () => {
    allNodes.value = store.getNodes();
  };
  const refreshVisibleNodes = () => {
    const isVirtual = virtualConfig?.isVirtualScroll.value;
    if (isVirtual) return;
    const list = [];
    let hasVisibleNode = false;
    allNodes.value.forEach((node) => {
      if (node.visible) {
        hasVisibleNode = true;
        cacheMap.set(node.value, node.value);
      }
      if (cacheMap.has(node.value)) {
        list.push(node);
      }
    });
    cacheMap.forEach((value) => {
      if (!store.getNode(value)) {
        cacheMap.delete(value);
      }
    });
    nodes.value = list;
    nodesEmpty.value = !hasVisibleNode;
  };
  const refreshVirtualNodes = () => {
    const isVirtual = virtualConfig?.isVirtualScroll.value;
    if (!isVirtual) return;
    const list = virtualConfig.visibleData.value;
    nodes.value = list;
    nodesEmpty.value = list.length <= 0;
  };
  const renderItem = (h6, node, index, stateId) => {
    const rowIndex = node.VIRTUAL_SCROLL_INDEX || index;
    const nodeUniqueId = node[privateKey];
    const treeItem = _createVNode11(tree_item_default, {
      "key": nodeUniqueId,
      "rowIndex": rowIndex,
      "stateId": stateId,
      "itemKey": nodeUniqueId,
      "treeScope": scope,
      "onClick": handleClick,
      "onChange": handleChange
    }, null);
    return treeItem;
  };
  const renderTreeNodes = (h6) => {
    const stateId = `render-${(/* @__PURE__ */ new Date()).getTime()}`;
    const treeNodeViews = nodes.value.map((node, index) => renderItem(h6, node, index, stateId));
    return treeNodeViews;
  };
  watch12(allNodes, refreshVisibleNodes);
  watch12(virtualConfig.visibleData, refreshVirtualNodes);
  refresh();
  refreshVisibleNodes();
  refreshVirtualNodes();
  store.emitter.on("update", refresh);
  return {
    nodesEmpty,
    renderTreeNodes
  };
}

// packages/components/tree/hooks/useTreeScroll.ts
import { get as get3 } from "lodash-es";
function useTreeScroll(state) {
  const treeState = state;
  const { props, context, allNodes, nodes, scope, treeContentRef, isScrolling } = treeState;
  const scrollProps = computed14(() => ({
    // 默认一行高度为 34px
    rowHeight: 34,
    ...props.scroll
  }));
  scope.scrollProps = scrollProps;
  const virtualScrollParams = computed14(() => {
    const list = allNodes.value.filter((node) => node.visible);
    return {
      data: list,
      scroll: scrollProps.value,
      preventResizeRefresh: true
    };
  });
  const virtualConfig = useVirtualScrollNew(treeContentRef, virtualScrollParams);
  scope.virtualConfig = virtualConfig;
  treeState.virtualConfig = virtualConfig;
  onMounted12(() => {
    const isVirtual = virtualConfig?.isVirtualScroll.value;
    if (isVirtual) {
      virtualConfig.handleScroll();
    }
  });
  const emitScrollEvent = (e) => {
    props.onScroll?.({ e });
    context.emit("scroll", { e });
  };
  let scrollStopTimer = null;
  const setScrolling = () => {
    isScrolling.value = true;
    if (scrollStopTimer) {
      clearTimeout(scrollStopTimer);
      scrollStopTimer = null;
    }
    scrollStopTimer = setTimeout(() => {
      scrollStopTimer = null;
      isScrolling.value = false;
    }, 100);
  };
  let lastScrollY = 0;
  const onInnerVirtualScroll = (e) => {
    setScrolling();
    const isVirtual = virtualConfig?.isVirtualScroll.value;
    const target = e.target || e.srcElement;
    const top = target.scrollTop;
    if (lastScrollY !== top) {
      if (isVirtual) {
        virtualConfig.handleScroll();
        nodes.value = virtualConfig.visibleData.value;
      }
    } else {
      lastScrollY = 0;
    }
    lastScrollY = top;
    emitScrollEvent(e);
  };
  const handleScrollTo = (params) => {
    let index = params.index;
    if (!index && index !== 0) {
      if (!params.key) {
        log_default2.error("Tree", "scrollToElement: one of `index` or `key` must exist.");
        return;
      }
      index = allNodes.value?.findIndex(
        (item) => [get3(item.data, "key"), get3(item.data, props.keys?.["value"] || "value")].includes(params.key)
      );
      if (index < 0) {
        log_default2.error("Tree", `${params.key} does not exist in data, check \`key\` or \`data\` please.`);
        return;
      }
    }
    virtualConfig.scrollToElement({ ...params, index: index - 1 });
  };
  return {
    // 虚拟滚动相关
    treeContentRef,
    onInnerVirtualScroll,
    virtualConfig,
    scrollToElement: handleScrollTo
  };
}

// packages/components/tree/hooks/useTreeState.ts
function useTreeState(props, context) {
  const treeContentRef = ref21();
  const nodes = ref21([]);
  const allNodes = ref21([]);
  const isScrolling = ref21(false);
  const refProps = toRefs5(props);
  const vmValue = useVModel2(props, refProps, "value", "defaultValue", "onChange", "change");
  const vmActived = useVModel2(props, refProps, "actived", "defaultActived", "onActive", "active");
  const vmExpanded = useVModel2(props, refProps, "expanded", "defaultExpanded", "onExpand", "expand");
  function setStore(store) {
    state.store = store;
    state.scope.store = store;
    allNodes.value = store.getNodes();
  }
  const state = {
    props,
    context,
    // tree 数据对象
    store: null,
    // 内容根节点
    treeContentRef,
    // 渲染节点
    nodes,
    // 所有节点
    allNodes,
    // 是否正在滚动
    isScrolling,
    // 缓存点击事件
    mouseEvent: null,
    // 虚拟滚动对象
    virtualConfig: null,
    // 缓存与节点共享的关联对象
    scope: {
      store: null,
      treeContentRef,
      treeProps: props,
      scopedSlots: {},
      virtualConfig: null
    },
    setStore,
    refProps,
    vmValue,
    vmActived,
    vmExpanded
  };
  return {
    state
  };
}

// packages/components/tree/hooks/useTreeStore.ts
import { pick } from "lodash-es";

// packages/common/js/tree/tree-store.ts
import { isArray as isArray7, isFunction as isFunction8, isNumber as isNumber3, isString as isString7, difference, camelCase as camelCase3, isPlainObject } from "lodash-es";
import mitt from "mitt";
function nextTick5(fn) {
  const pm = Promise.resolve();
  pm.then(fn);
  return pm;
}
var TreeStore = class {
  // 根节点集合
  children;
  // 所有节点集合
  nodes;
  // 所有节点映射
  nodeMap;
  // 节点 私有 ID 映射
  privateMap;
  // 配置选项
  config;
  // 活动节点集合
  activedMap;
  // 数据被更新的节点集合
  updatedMap;
  // 选中节点集合
  checkedMap;
  // 展开节点的集合
  expandedMap;
  // 符合过滤条件的节点的集合
  filterMap;
  // 存在过滤器标志
  hasFilter;
  // 事件派发器
  emitter;
  // 数据更新计时器
  updateTick;
  // 识别是否需要重排
  shouldReflow;
  // 树节点过滤器
  prevFilter;
  constructor(options) {
    const config = {
      prefix: "t",
      keys: {},
      expandAll: false,
      expandLevel: 0,
      expandMutex: false,
      expandParent: false,
      activable: false,
      activeMultiple: false,
      checkable: false,
      checkStrictly: false,
      disabled: false,
      disableCheck: false,
      draggable: false,
      load: null,
      lazy: false,
      valueMode: "onlyLeaf",
      filter: null,
      // 每次搜索条件变更，重置展开状态，路径节点展开，显示命中节点
      // allowFoldNodeOnFilter 为 true 时，搜索条件不变的情况下，允许折叠路径节点
      // 默认状态，allowFoldNodeOnFilter 为 false 时，路径节点无法折叠
      allowFoldNodeOnFilter: false,
      onLoad: null,
      onReflow: null,
      onUpdate: null,
      ...options
    };
    this.config = config;
    this.nodes = [];
    this.children = [];
    this.nodeMap = /* @__PURE__ */ new Map();
    this.privateMap = /* @__PURE__ */ new Map();
    this.activedMap = /* @__PURE__ */ new Map();
    this.expandedMap = /* @__PURE__ */ new Map();
    this.checkedMap = /* @__PURE__ */ new Map();
    this.updatedMap = /* @__PURE__ */ new Map();
    this.filterMap = /* @__PURE__ */ new Map();
    this.prevFilter = null;
    this.updateTick = null;
    this.shouldReflow = false;
    this.hasFilter = isFunction8(config.filter);
    this.emitter = mitt();
  }
  /**
   * 配置选项
   * @param {object} options tree 组件选项
   * @return void
   */
  setConfig(options) {
    const { config } = this;
    let hasChanged = false;
    Object.keys(options).forEach((key) => {
      const val = options[key];
      if (val !== config[key]) {
        hasChanged = true;
        config[key] = val;
      }
    });
    this.hasFilter = isFunction8(config.filter);
    if (hasChanged) {
      this.refreshState();
    }
  }
  /**
   * 获取根节点列表
   * @return TreeNode[] 根节点对象数组
   */
  getChildren() {
    return this.children;
  }
  /**
   * 获取指定节点对象
   * @param {string|number|TreeNode} item 获取节点对象的条件，可以是节点 value，也可以是节点本身
   * @return TreeNode 节点对象，如果判断树中没有符合条件的节点，返回 null
   */
  getNode(item) {
    let node = null;
    if (isString7(item) || isNumber3(item)) {
      node = this.nodeMap.get(item);
    } else if (item instanceof TreeNode) {
      node = this.nodeMap.get(item.value);
    }
    if (!node) node = null;
    return node;
  }
  /**
   * 获取节点在总节点列表中的位置
   * @param {TreeNode} node 节点对象
   * @return number 节点在总节点列表中的位置序号
   */
  getIndex(node) {
    return this.nodes.indexOf(node);
  }
  /**
   * 获取指定节点的父节点
   * @param {string} value 节点值
   * @return TreeNode 节点对象
   */
  getParent(value) {
    let parent = null;
    const node = this.getNode(value);
    if (node) {
      parent = node.getParent();
    }
    return parent;
  }
  /**
   * 获取指定节点的所有父节点
   * @param {string} value 节点值
   * @return TreeNode[] 父节点数组
   */
  getParents(value) {
    const node = this.getNode(value);
    let parents = [];
    if (node) {
      parents = node.getParents();
    }
    return parents;
  }
  /**
   * 获取指定节点在其所在 children 中的位置
   * @param {string} value 节点值
   * @return number 节点在 children 中的位置序号
   */
  getNodeIndex(value) {
    const node = this.getNode(value);
    let index = -1;
    if (node) {
      index = node.getIndex();
    }
    return index;
  }
  /**
   * 获取所有符合条件的节点，按回流排序后的顺序给出
   * 以这些字段作为示例:
   * - value: 节点值(ID)
   * - TreeNode: 节点实例
   * - level: 节点层级
   * - filter: 节点过滤函数
   * 支持下列使用方式
   * - getNodes() 获取所有节点
   * - getNodes(value) 获取节点值对应的目标节点下，包含自己在内的所有子节点
   * - getNodes(TreeNode) 获取目标节点下，包含自己在内的所有子节点
   * - getNodes(value, { level: 2 }) 获取目标节点下，层级在 2 以内的子节点
   * - getNodes(value, { filter: node => (!node.checked) }) 获取目标节点下，未选中的节点
   * - getNodes(value, { props: { actived: true } }) 获取目标节点下，已激活的节点
   * @param {string | TreeNode} [item] 节点值，节点对象
   * @param {object} [options] 节点过滤条件，可传递节点属性，过滤出属性一致的节点
   * @param {number} [options.level=Infinity] 节点层级
   * @param {function} [options.filter=null] 节点过滤条件函数
   * @param {object} [options.props] 节点属性对象，作为过滤条件
   * @return TreeNode[] 符合条件的节点数组
   */
  getNodes(item, options) {
    let nodes = [];
    let val = "";
    if (isString7(item) || isNumber3(item)) {
      val = item;
    } else if (item instanceof TreeNode) {
      val = item.value;
    }
    if (!val && val !== 0) {
      nodes = this.nodes.slice(0);
    } else {
      const node = this.getNode(val);
      if (node) {
        nodes = node.walk();
      }
    }
    if (options) {
      const conf = {
        filter: null,
        level: Infinity,
        ...options
      };
      if (isNumber3(conf.level) && conf.level !== Infinity) {
        nodes = nodes.filter((node) => node.level <= conf.level);
      }
      if (isFunction8(conf.filter)) {
        nodes = nodes.filter((node) => {
          const nodeModel = node.getModel();
          return conf.filter(nodeModel);
        });
      }
      if (isPlainObject(conf.props)) {
        nodes = nodes.filter((node) => {
          const result = Object.keys(conf.props).every((key) => {
            const propEqual = node[key] === conf.props[key];
            return propEqual;
          });
          return result;
        });
      }
    }
    return nodes;
  }
  /**
   * 添加新节点数据
   * @param {object[]} list 节点数据对象数组
   * @return void
   */
  append(list) {
    list.forEach((item) => {
      const node = new TreeNode(this, item);
      this.children.push(node);
    });
    this.reflow();
  }
  /**
   * 清空当前树的数据，重新加载数据
   * @param {object[]} list 节点数据对象数组
   * @return void
   */
  reload(list) {
    this.removeAll();
    this.append(list);
  }
  /**
   * 解析节点数据，适配多种节点类型
   * @param {string | TreeNode | object} para 树节点值，或者树节点，或者节点构造数据
   * @param {object | TreeNode} item 节点构造数据, 或者节点构造数据数组，或者树节点
   * @return spec 解析完成的数据结构
   * - {TreeNode} spec.node 目标树节点
   * - {object} spec.data 节点构造数据
   */
  parseNodeData(para, item) {
    let value = "";
    let node = null;
    let data = null;
    if (isString7(para) || isNumber3(para)) {
      value = para;
      node = this.getNode(value);
      data = item;
    } else if (para instanceof TreeNode) {
      if (item) {
        node = para;
        data = item;
      } else {
        data = para;
      }
    } else {
      data = para;
    }
    const spec = {
      node,
      data
    };
    return spec;
  }
  /**
   * 向指定节点追加节点或者数据
   * 以这些字段作为示例: item: 节点数据, TreeNode: 节点实例, value: 节点值(ID)
   * 支持下列使用方式
   * - appendNodes(item) 直接传递节点构造数据，新增节点
   * - appendNodes(TreeNode) 传递别的树的树节点，新增节点
   * - appendNodes(value, item) 以节点值查找指定节点，并新增节点构造数据
   * - appendNodes(value, TreeNode) 以节点值查找指定节点，并新增树节点
   * - appendNodes(TreeNode, item) 向指定节点新增节点构造数据
   * - appendNodes(TreeNode, TreeNode) 向指定节点新增树节点
   * @param {string | TreeNode | object} para 树节点值，或者树节点，或者节点构造数据
   * @param {object | TreeNode} [item] 节点构造数据, 或者节点构造数据数组，或者树节点
   * @return void
   */
  appendNodes(para, item) {
    const spec = this.parseNodeData(para, item);
    if (spec.data) {
      if (!spec.node) {
        if (spec.data instanceof TreeNode) {
          spec.data.appendTo(this);
        } else if (Array.isArray(spec.data)) {
          this.append(spec.data);
        } else {
          this.append([spec.data]);
        }
      } else {
        if (spec.data instanceof TreeNode) {
          spec.data.appendTo(this, spec.node);
        } else if (isArray7(spec.data)) {
          spec.node.append(spec.data);
        } else {
          spec.node.append([spec.data]);
        }
        spec.node.updateRelated();
      }
    }
  }
  /**
   * 在目标节点之前插入节点
   * @param {string | TreeNode} value 节点值，或者树节点
   * @param {object | TreeNode} item 节点构造数据, 或者树节点
   * @return void
   */
  insertBefore(value, item) {
    const node = this.getNode(value);
    if (node) {
      node.insertBefore(item);
    }
  }
  /**
   * 在目标节点之后插入节点
   * @param {string | TreeNode} value 节点值，或者树节点
   * @param {object | TreeNode} item 节点构造数据, 或者树节点
   * @return void
   */
  insertAfter(value, item) {
    const node = this.getNode(value);
    if (node) {
      node.insertAfter(item);
    }
  }
  /**
   * 更新树结构
   * - 清空 nodes 数组，然后遍历所有根节点重新插入 node
   * - 这个操作将会为树结构数据提供一个一纬数组索引
   * @return void
   */
  refreshNodes() {
    const { children, nodes } = this;
    nodes.length = 0;
    children.forEach((node) => {
      const list = node.walk();
      Array.prototype.push.apply(nodes, list);
    });
  }
  /**
   * 标记节点重排
   * - 应该仅在树节点增删改查时调用
   * - 节点重排会在延时后触发 refreshNodes 方法的调用
   * @param {TreeNode} [node] 触发重排的树节点
   * @return void
   */
  reflow(node) {
    this.shouldReflow = true;
    this.updated(node);
  }
  /**
   * 触发更新事件
   * - 节点属性变更时调用
   * - 统一延时后，处理需要在其他节点状态更新后再处理的逻辑，减少这类逻辑的重复调用开销
   * - 统一延时后，派发事件，通知树已更新完毕，以及回流完毕，触发 vue 视图渲染操作
   * @param {TreeNode} [node] 触发更新的树节点
   * @return void
   */
  updated(node) {
    const { updatedMap } = this;
    if (node) {
      updatedMap.set(node[privateKey], "changed");
    } else {
      this.getNodes().forEach((itemNode) => {
        updatedMap.set(itemNode[privateKey], "changed");
      });
    }
    if (this.updateTick) return;
    this.updateTick = nextTick5(() => {
      this.updateTick = null;
      if (this.shouldReflow) {
        this.refreshNodes();
        this.emit("reflow");
      }
      this.lockFilterPathNodes();
      const stateId = `t${(/* @__PURE__ */ new Date()).getTime()}`;
      const updatedList = Array.from(updatedMap.keys());
      const updatedNodes = updatedList.map((nodePrivateKey) => {
        updatedMap.set(nodePrivateKey, stateId);
        return this.privateMap.get(nodePrivateKey);
      });
      this.emit("update", {
        nodes: updatedNodes,
        map: updatedMap
      });
      this.shouldReflow = false;
      updatedMap.clear();
    });
  }
  /**
   * 获取激活节点集合
   * @param {Map} [map] 预设激活节点 map, 用于受控操作时预先获取结果而不直接操作节点状态
   * @return string[] 激活节点值数组
   */
  getActived(map) {
    const activedMap = map || this.activedMap;
    return Array.from(activedMap.keys());
  }
  /**
   * 获取指定范围的激活节点
   * - 范围是目标节点在内所有子节点
   * @param {string | TreeNode} [item] 目标节点值，或者目标节点本身
   * @return TreeNode[] 激活节点数组
   */
  getActivedNodes(item) {
    let nodes = this.getNodes(item);
    nodes = nodes.filter((node) => node.isActived());
    return nodes;
  }
  /**
   * 替换激活态
   * @param {string[]} list 目标节点值数组
   * @return void
   */
  replaceActived(list) {
    this.resetActived();
    this.setActived(list);
  }
  /**
   * 设置激活态
   * @param {string[]} list 目标节点值数组
   * @return void
   */
  setActived(actived) {
    const { activeMultiple } = this.config;
    const list = actived.slice(0);
    if (!activeMultiple) {
      list.length = 1;
    }
    list.forEach((val) => {
      this.activedMap.set(val, true);
      const node = this.getNode(val);
      if (node) {
        node.update();
      }
    });
  }
  /**
   * 清空所有节点的激活状态
   * @return void
   */
  resetActived() {
    const actived = this.getActived();
    this.activedMap.clear();
    const relatedNodes = this.getRelatedNodes(actived);
    relatedNodes.forEach((node) => {
      node.update();
    });
  }
  /**
   * 获取展开节点集合
   * @param {Map} [map] 预设展开节点 map, 用于受控操作时预先获取结果而不直接操作节点状态
   * @return void
   */
  getExpanded(map) {
    const expandedMap = map || this.expandedMap;
    return Array.from(expandedMap.keys());
  }
  /**
   * 替换展开节点
   * @param {string[]} list 目标节点值数组
   * @return void
   */
  replaceExpanded(list) {
    const expanded = this.getExpanded();
    const added = difference(list, expanded);
    const removed = difference(expanded, list);
    this.setExpandedDirectly(removed, false);
    this.updateExpanded(removed);
    this.setExpanded(added);
  }
  /**
   * 批量设置展开节点
   * - 注意这个状态设置操作会忽略互斥属性
   * @param {string[]} list 目标节点值数组
   * @return void
   */
  setExpanded(list) {
    this.setExpandedDirectly(list);
    this.updateExpanded(list);
  }
  /**
   * 直接设置节点展开状态
   * - 注意这个状态设置操作会忽略互斥属性
   * @param {string[]} list 目标节点值数组
   * @param {boolean} [expanded=true] 展开状态
   * @return void
   */
  setExpandedDirectly(list, expanded = true) {
    list.forEach((val) => {
      const node = this.getNode(val);
      if (!node?.isLeaf() && expanded) {
        this.expandedMap.set(val, true);
      } else {
        this.expandedMap.delete(val);
      }
      node?.afterExpanded();
    });
  }
  /**
   * 清除所有节点的展开状态
   * @return void
   */
  resetExpanded() {
    const expanded = this.getExpanded();
    this.expandedMap.clear();
    this.updateExpanded(expanded);
  }
  /**
   * 更新展开节点相关节点的状态
   * - 节点展开状态变更后，上下游节点可能存在状态变更，统一纳入待更新队列
   * @param {string[]} list 目标节点值数组
   * @return void
   */
  updateExpanded(list) {
    const relatedNodes = this.getRelatedNodes(list, {
      withParents: false
    });
    relatedNodes.forEach((node) => {
      node.update();
    });
  }
  /**
   * 获取选中态节点值数组
   * @param {Map} [map] 预设选中节点 map, 用于受控操作时预先获取结果而不直接操作节点状态
   * @return string[] 选中态节点 value 数组
   */
  getChecked(map) {
    const { nodeMap, config } = this;
    const { valueMode, checkStrictly } = config;
    const list = [];
    const checkedMap = map || this.checkedMap;
    nodeMap.forEach((node) => {
      if (!node.isChecked(checkedMap)) return;
      if (valueMode === "parentFirst" && !checkStrictly) {
        if (node.isDisabled() || !node.parent || !node.parent.isChecked(checkedMap)) {
          list.push(node.value);
        }
      } else if (valueMode === "onlyLeaf" && !checkStrictly) {
        if (node.isLeaf()) {
          list.push(node.value);
        }
      } else {
        list.push(node.value);
      }
    });
    return list;
  }
  /**
   * 获取指定节点下的选中节点
   * @param {string | TreeNode} [item] 目标节点值，或者目标节点
   * @return TreeNode[] 选中节点数组
   */
  getCheckedNodes(item) {
    let nodes = this.getNodes(item);
    nodes = nodes.filter((node) => node.isChecked());
    return nodes;
  }
  /**
   * 替换选中态列表
   * @param {string[]} list 目标节点值数组
   * @return void
   */
  replaceChecked(list) {
    this.resetChecked();
    this.setChecked(list);
  }
  /**
   * 批量设置选中态
   * @param {string[]} list 目标节点值数组
   * @return void
   */
  setChecked(list) {
    const { checkStrictly, checkable } = this.config;
    if (!checkable) return;
    list.forEach((val) => {
      const node = this.getNode(val);
      if (!node) return;
      if (checkStrictly) {
        this.checkedMap.set(val, true);
        node.updateChecked();
      } else {
        const childrenNodes = node.walk();
        childrenNodes.forEach((childNode) => {
          if (childNode !== node && childNode.isDisabled()) return;
          this.checkedMap.set(childNode.value, true);
        });
      }
    });
    if (!checkStrictly) {
      const checkedValues = this.getChecked();
      const relatedNodes = this.getRelatedNodes(checkedValues);
      relatedNodes.forEach((node) => {
        node.updateChecked();
      });
    }
  }
  /**
   * 清除所有节点选中态
   * @return void
   */
  resetChecked() {
    const checked = this.getChecked();
    const relatedNodes = this.getRelatedNodes(checked);
    this.checkedMap.clear();
    relatedNodes.forEach((node) => {
      node.updateChecked();
    });
  }
  /**
   * 更新所有树节点状态，但不更新选中态
   * 用于不影响选中态时候的更新，减少递归循环造成的时间消耗
   * @return void
   */
  refreshState() {
    const { nodeMap } = this;
    nodeMap.forEach((node) => {
      node.update();
    });
  }
  /**
   * 更新全部节点状态
   * @return void
   */
  updateAll() {
    const { nodeMap } = this;
    nodeMap.forEach((node) => {
      node.update();
      node.updateChecked();
    });
  }
  /**
   * 移除指定节点
   * @param {string} value 目标节点值
   * @return void
   */
  remove(value) {
    const node = this.getNode(value);
    if (node) {
      node.remove();
    }
  }
  /**
   * 移除所有节点
   * @return void
   */
  removeAll() {
    this.expandedMap.clear();
    this.checkedMap.clear();
    this.activedMap.clear();
    this.filterMap.clear();
    this.nodeMap.clear();
    this.privateMap.clear();
    this.updatedMap.clear();
    this.nodes = [];
    this.children = [];
    this.reflow();
  }
  /**
   * 获取节点状态变化可能影响的关联节点
   * - 用于实现最小遍历集合
   * @param {string[]} list 目标节点值数组
   * @param {object} [options] 操作选项
   * @oaran {boolean} [options.reverse=false] 倒序排列遍历节点
   * @param {boolean} [options.withParents=true] 包含所有父节点
   * @return TreeNode[] 关联节点数组
   */
  getRelatedNodes(list, options) {
    const conf = {
      // 默认倒序排列，从底层节点开始遍历
      reverse: false,
      // 默认遍历父节点
      withParents: true,
      ...options
    };
    const map = /* @__PURE__ */ new Map();
    list.forEach((value) => {
      if (map.get(value)) return;
      const node = this.getNode(value);
      if (node) {
        const parents = node.getParents().reverse();
        const children = node.walk();
        let related = [];
        if (conf.withParents) {
          related = parents.concat(children);
        } else {
          related = children;
        }
        related.forEach((relatedNode) => {
          map.set(relatedNode.value, relatedNode);
        });
      }
    });
    let relatedNodes = Array.from(map.values());
    if (conf.reverse) {
      relatedNodes = relatedNodes.reverse();
    }
    return relatedNodes;
  }
  /**
   * 触发绑定的事件
   * - store.emitter 可以绑定事件回调，用于多个组件共同监听事件
   * @param {string} name 事件名称
   * @param {Event} [state] 事件对象
   * @param {TreeNode} [state.node] 事件关联节点
   * @param {TreeNode[]} [state.nodes] 事件关联节点数组
   * @param {Map} [state.map] 事件关联节点映射
   * @param {object[]} [state.data] 事件关联节点数据
   * @return void
   */
  emit(name, state) {
    const { config, emitter } = this;
    const methodName = camelCase3(`on-${name}`);
    const method = config[methodName];
    if (isFunction8(method)) {
      method(state);
    }
    emitter.emit(name, state);
  }
  /**
   * 锁定过滤节点的路径节点
   * - 使得路径节点自动展开
   * @return void
   */
  lockFilterPathNodes() {
    const { config } = this;
    const allNodes = this.getNodes();
    if (this.prevFilter) {
      allNodes.forEach((node) => {
        if (node.vmIsLocked) {
          node.lock(false);
        }
      });
    }
    const currentFilter = config.filter;
    if (!currentFilter || !isFunction8(currentFilter)) return;
    this.prevFilter = config.filter;
    allNodes.reverse().forEach((node) => {
      const parent = node.getParent();
      if (!parent) return;
      if (node.vmIsRest || node.vmIsLocked) {
        if (!parent.vmIsLocked) {
          parent.lock(true);
        }
      }
    });
  }
};

// packages/components/tree/hooks/useTreeStore.ts
function useTreeStore(state) {
  const { props, context, refProps } = state;
  const { valueMode, filter, keys } = props;
  const store = new TreeStore({
    valueMode,
    filter
  });
  const tValue = state.vmValue[0];
  const tActived = state.vmActived[0];
  const tExpanded = state.vmExpanded[0];
  const updateStoreConfig = () => {
    const storeProps = pick(props, [
      "expandAll",
      "expandLevel",
      "expandMutex",
      "expandParent",
      "activable",
      "activeMultiple",
      "disabled",
      "disableCheck",
      "checkable",
      "draggable",
      "checkStrictly",
      "load",
      "lazy",
      "valueMode",
      "filter",
      "allowFoldNodeOnFilter"
    ]);
    store.setConfig(storeProps);
  };
  const updateExpanded = () => {
    const { expandParent } = props;
    if (!Array.isArray(tExpanded.value)) return;
    const expandedMap = /* @__PURE__ */ new Map();
    tExpanded.value.forEach((val) => {
      expandedMap.set(val, true);
      if (expandParent) {
        const node = store.getNode(val);
        if (node) {
          node.getModel().getParents().forEach((tn) => {
            expandedMap.set(tn.value, true);
          });
        }
      }
    });
    const expandedArr = Array.from(expandedMap.keys());
    store.setExpanded(expandedArr);
  };
  let filterChanged = false;
  let prevExpanded = null;
  const expandFilterPath = () => {
    if (!props.allowFoldNodeOnFilter) return;
    if (!filterChanged) return;
    filterChanged = false;
    if (props.filter) {
      if (!prevExpanded) {
        prevExpanded = store.getExpanded();
      }
      const pathValues = [];
      const allNodes = store.getNodes();
      allNodes.forEach((node) => {
        if (node.vmIsLocked) {
          pathValues.push(node.value);
        }
      });
      store.setExpanded(pathValues);
    } else if (prevExpanded) {
      store.replaceExpanded(prevExpanded);
      prevExpanded = null;
    }
  };
  const checkFilterExpand = (newFilter, previousFilter) => {
    if (!props.allowFoldNodeOnFilter) return;
    filterChanged = newFilter !== previousFilter;
  };
  const handleLoad = (info) => {
    const { node } = info;
    const evtCtx = {
      node: node.getModel()
    };
    if (Array.isArray(tValue.value) && tValue.value.length > 0) {
      store.replaceChecked(tValue.value);
    }
    if (Array.isArray(tExpanded.value) && tExpanded.value.length > 0) {
      store.replaceExpanded(tExpanded.value);
    }
    if (Array.isArray(tActived.value) && tActived.value.length > 0) {
      store.replaceActived(tActived.value);
    }
    if (props?.onLoad) {
      props?.onLoad(evtCtx);
    }
    context.emit("load", evtCtx);
  };
  const rebuild = (list) => {
    store.reload(list || []);
    store.refreshNodes();
    if (Array.isArray(tValue.value)) {
      store.setChecked(tValue.value);
    }
    updateExpanded();
    if (Array.isArray(tActived.value)) {
      store.setActived(tActived.value);
    }
    store.refreshState();
  };
  function initStore() {
    store.setConfig({
      keys
    });
    updateStoreConfig();
    store.append(props.data || []);
    store.refreshNodes();
    if (Array.isArray(tValue.value)) {
      store.setChecked(tValue.value);
    }
    updateExpanded();
    if (Array.isArray(tActived.value)) {
      store.setActived(tActived.value);
    }
    store.emitter.on("load", handleLoad);
    store.emitter.on("update", expandFilterPath);
  }
  initStore();
  state.setStore(store);
  watch12(
    () => [...tValue.value || []],
    (nVal) => {
      store.replaceChecked(nVal);
    }
  );
  watch12(
    () => [...tExpanded.value || []],
    (nVal) => {
      store.replaceExpanded(nVal);
    }
  );
  watch12(
    () => [...tActived.value || []],
    (nVal) => {
      store.replaceActived(nVal);
    }
  );
  watch12(refProps.filter, (nVal, previousVal) => {
    checkFilterExpand(nVal, previousVal);
  });
  watch12(refProps.keys, (keys2) => {
    store.setConfig({
      keys: keys2
    });
  });
  watch12(refProps.expandAll, (nVal) => {
    if (nVal) {
      const valueList = store.getNodes().filter((node) => Array.isArray(node.children) && node.children.length).map((node) => node.value);
      store.setExpanded(valueList);
    } else {
      store.replaceExpanded(prevExpanded);
      prevExpanded = null;
    }
  });
  return {
    store,
    rebuild,
    checkFilterExpand,
    updateStoreConfig,
    updateExpanded,
    expandFilterPath
  };
}

// packages/components/tree/hooks/useTreeStyles.ts
function formatCSSUnit(unit) {
  if (!unit) return unit;
  return isNaN(Number(unit)) ? unit : `${unit}px`;
}
function useTreeStyles(state) {
  const { props } = state;
  const componentName = usePrefixClass("tree").value;
  const classPrefix = usePrefixClass().value;
  const { virtualConfig, isScrolling, refProps } = state;
  const { height, maxHeight } = refProps;
  const treeClasses = computed14(() => {
    const list = [componentName];
    const { disabled, hover, transition, checkable, draggable, expandOnClickNode, scroll } = props;
    if (disabled) {
      list.push(`${classPrefix}-is-disabled`);
    }
    if (hover) {
      list.push(`${componentName}--hoverable`);
    }
    if (checkable) {
      list.push(`${componentName}--checkable`);
    }
    if (draggable) {
      list.push(`${componentName}--draggable`);
    }
    if (transition) {
      list.push(`${componentName}--transition`);
    }
    if (expandOnClickNode) {
      list.push(`${componentName}--block-node`);
    }
    const isVirtual = virtualConfig?.isVirtualScroll.value;
    if (isVirtual) {
      list.push(`${componentName}__vscroll`);
      if (isScrolling.value) {
        list.push(`${componentName}--scrolling`);
      }
    } else if (scroll && scroll.type === "lazy") {
      list.push(`${componentName}__lazyload`);
    }
    return list;
  });
  const treeContentStyles = computed14(() => ({
    height: formatCSSUnit(height.value),
    maxHeight: formatCSSUnit(maxHeight.value),
    overflowY: formatCSSUnit(height.value) || formatCSSUnit(maxHeight.value) ? "auto" : void 0
  }));
  const scrollStyles = computed14(() => {
    const isVirtual = virtualConfig?.isVirtualScroll.value;
    const translateY = isVirtual ? virtualConfig?.translateY.value : 0;
    const transform = `translateY(${translateY}px)`;
    const posStyle = {
      transform,
      "-ms-transform": transform,
      "-moz-transform": transform,
      "-webkit-transform": transform
    };
    return posStyle;
  });
  const cursorStyles = computed14(() => {
    const isVirtual = virtualConfig?.isVirtualScroll.value;
    const translateY = isVirtual ? virtualConfig?.translateY.value : 0;
    const translate = `translate(0, ${translateY}px)`;
    return {
      transform: translate,
      "-ms-transform": translate,
      "-moz-transform": translate,
      "-webkit-transform": translate
    };
  });
  return {
    treeClasses,
    treeContentStyles,
    scrollStyles,
    cursorStyles
  };
}

// packages/components/tree/props.ts
var props_default3 = {
  /** 节点是否可高亮 */
  activable: Boolean,
  /** 是否允许多个节点同时高亮 */
  activeMultiple: Boolean,
  /** 高亮的节点值 */
  actived: {
    type: Array,
    default: void 0
  },
  /** 高亮的节点值，非受控属性 */
  defaultActived: {
    type: Array
  },
  /** 判断节点是否可以执行 drop 操作，泛型 `T` 表示树节点 TS 类型 */
  allowDrop: {
    type: Function
  },
  /** 是否允许在过滤时节点折叠节点 */
  allowFoldNodeOnFilter: Boolean,
  /** 透传属性到 checkbox 组件。参考 checkbox 组件 API */
  checkProps: {
    type: Object
  },
  /** 父子节点选中状态不再关联，可各自选中或取消 */
  checkStrictly: Boolean,
  /** 隐藏节点复选框 */
  checkable: Boolean,
  /** 树数据，泛型 `T` 表示树节点 TS 类型 */
  data: {
    type: Array,
    default: () => []
  },
  /** 禁用复选框，可支持禁用不同的行 */
  disableCheck: {
    type: [Boolean, Function],
    default: false
  },
  /** 是否禁用树操作 */
  disabled: Boolean,
  /** 节点是否可拖拽 */
  draggable: Boolean,
  /** 数据为空时展示的文本 */
  empty: {
    type: [String, Function],
    default: ""
  },
  /** 是否展开全部节点 */
  expandAll: Boolean,
  /** 默认展开的级别，第一层为 0 */
  expandLevel: {
    type: Number,
    default: 0
  },
  /** 同级别展开互斥，手风琴效果 */
  expandMutex: Boolean,
  /** 是否支持点击节点也能展开收起 */
  expandOnClickNode: Boolean,
  /** 展开子节点时是否自动展开父节点 */
  expandParent: Boolean,
  /** 展开的节点值 */
  expanded: {
    type: Array,
    default: void 0
  },
  /** 展开的节点值，非受控属性 */
  defaultExpanded: {
    type: Array,
    default: () => []
  },
  /** 节点过滤方法，只呈现返回值为 true 的节点，泛型 `T` 表示树节点 TS 类型 */
  filter: {
    type: Function
  },
  /** 树的高度，超出后会出现滚动条。示例：100,  '30%',  '300'。值为数字类型，会自动加上单位 px。如果不是绝对固定树的高度，建议使用 `maxHeight` */
  height: {
    type: [String, Number]
  },
  /** 节点是否有悬浮状态 */
  hover: Boolean,
  /** 节点图标，可自定义 */
  icon: {
    type: [Boolean, Function],
    default: true
  },
  /** 用来定义 `value / label / disabled / children` 在 `data` 数据中对应的字段别名，示例：`{ value: 'key', label 'name', children: 'list' }`。其中，disabled 待开发。 */
  keys: {
    type: Object
  },
  /** 自定义节点内容，值为 `false` 不显示，值为 `true` 显示默认 label，值为字符串直接输出该字符串。泛型 `T` 表示树节点 TS 类型。<br/>如果期望只有点击复选框才选中，而点击节点不选中，可以使用 `label` 自定义节点，然后加上点击事件 `e.preventDefault()`，通过调整自定义节点的宽度和高度决定禁止点击选中的范围 */
  label: {
    type: [String, Boolean, Function],
    default: true
  },
  /** 延迟加载 children 为 true 的节点的子节点数据，即使 expandAll 被设置为 true，也同样延迟加载 */
  lazy: {
    type: Boolean,
    default: true
  },
  /** 连接线。值为 false 不显示连接线；值为 true 显示默认连接线；值类型为 Function 表示自定义连接线 */
  line: {
    type: [Boolean, Function],
    default: false
  },
  /** 加载子数据的方法，在展开节点时调用（仅当节点 children 为 true 时生效），泛型 `T` 表示树节点 TS 类型 */
  load: {
    type: Function
  },
  /** 树的最大高度，超出后会出现滚动条。示例：100, '30%', '300'。值为数字类型，会自动加上单位 px */
  maxHeight: {
    type: [String, Number]
  },
  /** 自定义节点操作项，泛型 `T` 表示树节点 TS 类型 */
  operations: {
    type: Function
  },
  /** 懒加载和虚拟滚动。为保证组件收益最大化，当数据量小于阈值 `scroll.threshold` 时，无论虚拟滚动的配置是否存在，组件内部都不会开启虚拟滚动，`scroll.threshold` 默认为 `100` */
  scroll: {
    type: Object
  },
  /** 节点展开折叠时是否使用过渡动画 */
  transition: {
    type: Boolean,
    default: true
  },
  /** 选中值，组件为可选状态时有效 */
  value: {
    type: Array,
    default: void 0
  },
  modelValue: {
    type: Array,
    default: void 0
  },
  /** 选中值，组件为可选状态时有效，非受控属性 */
  defaultValue: {
    type: Array,
    default: () => []
  },
  /** 选中值模式。all 表示父节点和子节点全部会出现在选中值里面；parentFirst 表示当子节点全部选中时，仅父节点在选中值里面；onlyLeaf 表示无论什么情况，选中值仅呈现叶子节点 */
  valueMode: {
    type: String,
    default: "onlyLeaf",
    validator(val) {
      if (!val) return true;
      return ["onlyLeaf", "parentFirst", "all"].includes(val);
    }
  },
  /** 节点激活时触发，泛型 `T` 表示树节点 TS 类型 */
  onActive: Function,
  /** 节点选中状态变化时触发，context.node 表示当前变化的选项，泛型 `T` 表示树节点 TS 类型 */
  onChange: Function,
  /** 节点点击时触发，泛型 `T` 表示树节点 TS 类型 */
  onClick: Function,
  /** 节点结束拖拽时触发，泛型 `T` 表示树节点 TS 类型 */
  onDragEnd: Function,
  /** 节点拖拽时离开目标元素时触发，泛型 `T` 表示树节点 TS 类型 */
  onDragLeave: Function,
  /** 节点拖拽到目标元素时触发，泛型 `T` 表示树节点 TS 类型 */
  onDragOver: Function,
  /** 节点开始拖拽时触发，泛型 `T` 表示树节点 TS 类型 */
  onDragStart: Function,
  /** 节点在目标元素上释放时触发，泛型 `T` 表示树节点 TS 类型 */
  onDrop: Function,
  /** 节点展开或收起时触发，泛型 `T` 表示树节点 TS 类型 */
  onExpand: Function,
  /** 异步加载后触发，泛型 `T` 表示树节点 TS 类型 */
  onLoad: Function,
  /** 滚动事件 */
  onScroll: Function
};

// packages/components/tree/tree.tsx
function _isSlot2(s) {
  return typeof s === "function" || Object.prototype.toString.call(s) === "[object Object]" && !_isVNode2(s);
}
var tree_default = defineComponent6({
  name: "TTree",
  model: {
    prop: "value",
    event: "change"
  },
  props: props_default3,
  setup(props, context) {
    const {
      t: t2,
      global
    } = useConfig("tree");
    const classPrefix = usePrefixClass();
    const componentName = usePrefixClass("tree");
    const renderTNodeJSX = useTNodeJSX();
    const {
      state
    } = useTreeState(props, context);
    const {
      treeContentRef,
      isScrolling
    } = state;
    const {
      store,
      updateStoreConfig,
      rebuild
    } = useTreeStore(state);
    useDragHandle(state);
    const {
      setActived,
      setExpanded,
      setChecked
    } = useTreeAction(state);
    const {
      onInnerVirtualScroll,
      virtualConfig,
      scrollToElement
    } = useTreeScroll(state);
    const {
      renderTreeNodes,
      nodesEmpty
    } = useTreeNodes(state);
    const {
      treeClasses,
      treeContentStyles,
      scrollStyles,
      cursorStyles
    } = useTreeStyles(state);
    return {
      t: t2,
      global,
      classPrefix,
      componentName,
      state,
      store,
      treeClasses,
      treeContentRef,
      renderTNodeJSX,
      rebuild,
      updateStoreConfig,
      setActived,
      setExpanded,
      setChecked,
      renderTreeNodes,
      nodesEmpty,
      isScrolling,
      onInnerVirtualScroll,
      treeContentStyles,
      scrollStyles,
      cursorStyles,
      virtualConfig,
      scrollToElement,
      // deprecated
      scrollTo: scrollToElement
    };
  },
  watch: {
    // 实测发现，composition api 中的 refsProps watch ，回调时间迟于 $nextTick 回调
    // 因此改为在这里绑定 data 属性监听，实测这里的 watch 回调，早于 $nextTick 回调发生
    data(list) {
      this.rebuild(list);
    }
  },
  // 在 methods 提供公共方法
  // 实例上可以直接访问
  methods: {
    // 刷新树节点状态
    refresh() {
      this.store.refreshState();
    },
    // 设置目标节点状态
    setItem(value, options) {
      const node = this.store.getNode(value);
      const spec = options;
      const keys = Object.keys(spec);
      if (node && spec) {
        ["expanded", "actived", "checked"].forEach((name) => {
          if (keys.includes(name)) {
            const val = spec[name];
            delete spec[name];
            const methodName = `set${upperFirst(name)}`;
            const setupMethod = this[methodName];
            if (isFunction9(setupMethod)) {
              setupMethod.call(this, node, val);
            }
          }
        });
        node.set(spec);
      }
    },
    // 获取目标节点
    getItem(value) {
      const node = this.store.getNode(value);
      return node?.getModel();
    },
    // 无 value 参数: 获取 tree 所有节点，一维结构
    // 传递 value 参数: 获取节点值对应的目标节点下，包含自己在内的所有子节点
    getItems(value) {
      const nodes = this.store.getNodes(value);
      return nodes.map((node) => node.getModel());
    },
    // 将节点数据插入到目标节点
    // 无目标节点，则插入为根节点
    appendTo(para, item) {
      const {
        store
      } = this;
      let list = [];
      if (Array.isArray(item)) {
        list = item;
      } else {
        list = [item];
      }
      list.forEach((item2) => {
        const val = item2?.value || "";
        const node = getNode(store, val);
        if (node) {
          store.appendNodes(para, node);
        } else {
          store.appendNodes(para, item2);
        }
      });
    },
    // 在指定节点之前插入单个节点数据
    insertBefore(value, item) {
      const {
        store
      } = this;
      const val = item?.value || "";
      const node = getNode(store, val);
      if (node) {
        store.insertBefore(value, node);
      } else {
        store.insertBefore(value, item);
      }
    },
    // 在指定节点之后插入单个节点数据
    insertAfter(value, item) {
      const {
        store
      } = this;
      const val = item?.value || "";
      const node = getNode(store, val);
      if (node) {
        store.insertAfter(value, node);
      } else {
        store.insertAfter(value, item);
      }
    },
    // 移除目标节点
    remove(value) {
      return this.store.remove(value);
    },
    // 获取节点在当前层级的 index
    getIndex(value) {
      return this.store.getNodeIndex(value);
    },
    // 获取父节点
    getParent(value) {
      const node = this.store.getParent(value);
      return node?.getModel();
    },
    // 获取父节点列表
    getParents(value) {
      const nodes = this.store.getParents(value);
      return nodes.map((node) => node.getModel());
    },
    // 获取路径节点列表
    getPath(value) {
      const node = this.store.getNode(value);
      let pathNodes = [];
      if (node) {
        pathNodes = node.getPath().map((node2) => node2.getModel());
      }
      return pathNodes;
    },
    // 提供树结构原始数据
    getTreeData(value) {
      let list = [];
      if (value) {
        const node = this.store.getNode(value);
        if (!node) return [];
        list = this.store.getNodes(value);
      } else {
        list = this.store.getNodes();
      }
      const nodeMap = {};
      const treeNodes = [];
      list.forEach((item) => {
        const {
          value: value2
        } = item;
        const itemData = {
          ...item.data,
          value: value2
        };
        if (itemData.children !== true) {
          delete itemData.children;
        }
        nodeMap[value2] = itemData;
        const parent = item.getParent();
        if (!parent) {
          treeNodes.push(itemData);
        } else {
          const parentData = nodeMap[parent.value];
          if (!parentData) {
            treeNodes.push(itemData);
          } else {
            if (!Array.isArray(parentData.children)) {
              parentData.children = [];
            }
            parentData.children.push(itemData);
          }
        }
      });
      return treeNodes;
    }
  },
  render(h6) {
    const {
      state,
      treeClasses,
      updateStoreConfig,
      renderTreeNodes,
      nodesEmpty,
      isScrolling,
      virtualConfig,
      treeContentStyles,
      scrollStyles,
      cursorStyles
    } = this;
    const createElement = getCreateElement(h6);
    const {
      scope,
      allNodes,
      refProps
    } = state;
    scope.scopedSlots = getScopedSlots(this);
    updateStoreConfig();
    const treeNodeViews = renderTreeNodes(createElement);
    const cname = this.componentName;
    const isVirtual = virtualConfig.isVirtualScroll.value;
    let emptyNode = null;
    if (nodesEmpty) {
      const useLocale = !this.empty && !this.$slots.empty;
      const emptyContent = useLocale ? this.t(this.global.empty) : this.renderTNodeJSX("empty");
      emptyNode = _createVNode12("div", {
        "class": `${cname}__empty`
      }, [emptyContent]);
    } else if (treeNodeViews.length <= 0) {
      emptyNode = _createVNode12("div", null, null);
    }
    const {
      $props
    } = this;
    const {
      transition
    } = $props;
    let treeNodeList = null;
    if (!transition || isVirtual && isScrolling) {
      treeNodeList = _createVNode12("div", {
        "class": `${cname}__list`,
        "style": scrollStyles
      }, [treeNodeViews]);
    } else {
      treeNodeList = _createVNode12(TransitionGroup, {
        "tag": "div",
        "class": `${cname}__list`,
        "enter-active-class": `${cname}__item--enter-active`,
        "leave-active-class": `${cname}__item--leave-active`,
        "style": scrollStyles
      }, _isSlot2(treeNodeViews) ? treeNodeViews : {
        default: () => [treeNodeViews]
      });
    }
    const topValue = (allNodes.value?.filter((node) => node.visible).length ?? 0) * (refProps.scroll.value?.rowHeight ?? 34);
    const placeholderStyles = {
      width: "1px",
      height: "1px",
      opacity: 0,
      pointerEvents: "none",
      position: "absolute",
      left: 0,
      top: `${topValue}px`
    };
    const placeholderEl = _createVNode12("div", {
      "style": placeholderStyles
    }, null);
    const treeNode = _createVNode12("div", {
      "class": treeClasses,
      "ref": "treeContentRef",
      "onScroll": this.onInnerVirtualScroll,
      "style": treeContentStyles
    }, [isVirtual && _createVNode12("div", {
      "class": `${cname}__vscroll-cursor`,
      "style": cursorStyles
    }, null), emptyNode || treeNodeList, isVirtual && placeholderEl]);
    return treeNode;
  }
});
export {
  tree_default as default
};
